# Uefy 2 (Pro Edition)

Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq - https://www.rakiz.com

Uefy 2 is an addon for Blender that provides tools to make Rigify rigs suitable for use in game engines.

The *Pro Edition* is not limited to the unreal mannequin and similar characters. It easier to use, has more functionality and can update nearly any type of rigify rig from machines to fantasy creatures.

# How to Buy?

The **Uefy 2 (Pro Edition)** is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support this project and help ensure continued development.

## Available Support

Only limited support is provided in the form of community posts and publicly available instructional videos.

You can check FAQ on the offical site and usage videos on youtube at the following links.

- website: [Project Site](https://www.rakiz.com/uefy)
- youtube: [Youtube Channel Tutorials](https://youtube.com/RakizFarooq)

## License

This software is licensed under GNU GPLv3. Check LICENSE file for more details

## How to install

Use Blender menu Edit -> Preferences -> Addons -> Install to select the downloaded zip file.

See FAQ on offical site for more details

## Required Blender Version

This script is designed for Blender 2.83 LTS and above.


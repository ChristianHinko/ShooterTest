"""
Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq
https://www.rakiz.com

Created by Rakiz Farooq

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

"""
Uefy 2 is an addon for Blender that provides tools to make Rigify rigs 
suitable for use in game engines.

This addon is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support 
this project and help ensure continued development.
"""
import bpy
import json
import mathutils
import math
import os

from bpy.props import StringProperty
from bpy.props import IntProperty

class UEFY_OT_scan_anim(bpy.types.Operator):
    bl_idname = "uefy.scan_anim"
    bl_label = "Scan Animation"
    bl_description = "Scan the animation armature to create options"
    
    source_name : StringProperty()
    
    mapping = {
        "root" : ("root", True, True, True),
        "pelvis" : ("spine_fk", True, True, True),
        "spine_01" : ("spine_fk.001", True, True, True),
        "spine_02" : ("spine_fk.002", True, True, True),
        "spine_03" : ("spine_fk.003", True, True, True),
        "clavicle_l" : ("shoulder.L", True, True, True),
        "upperarm_l" : ("upper_arm_fk.L", True, True, True),
        "lowerarm_l" : ("forearm_fk.L", True, True, True),
        "hand_l" : ("hand_fk.L", True, True, True),
        "index_01_l" : ("f_index.01.L", True, True, True),
        "index_02_l" : ("f_index.02.L", True, True, True),
        "index_03_l" : ("f_index.03.L", True, True, True),
        "middle_01_l" : ("f_middle.01.L", True, True, True),
        "middle_02_l" : ("f_middle.02.L", True, True, True),
        "middle_03_l" : ("f_middle.03.L", True, True, True),
        "pinky_01_l" : ("f_pinky.01.L", True, True, True),
        "pinky_02_l" : ("f_pinky.02.L", True, True, True),
        "pinky_03_l" : ("f_pinky.03.L", True, True, True),
        "ring_01_l" : ("f_ring.01.L", True, True, True),
        "ring_02_l" : ("f_ring.02.L", True, True, True),
        "ring_03_l" : ("f_ring.03.L", True, True, True),
        "thumb_01_l" : ("thumb.01.L", True, True, True),
        "thumb_02_l" : ("thumb.02.L", True, True, True),
        "thumb_03_l" : ("thumb.03.L", True, True, True),
        "clavicle_r" : ("shoulder.R", True, True, True),
        "upperarm_r" : ("upper_arm_fk.R", True, True, True),
        "lowerarm_r" : ("forearm_fk.R", True, True, True),
        "hand_r" : ("hand_fk.R", True, True, True),
        "index_01_r" : ("f_index.01.R", True, True, True),
        "index_02_r" : ("f_index.02.R", True, True, True),
        "index_03_r" : ("f_index.03.R", True, True, True),
        "middle_01_r" : ("f_middle.01.R", True, True, True),
        "middle_02_r" : ("f_middle.02.R", True, True, True),
        "middle_03_r" : ("f_middle.03.R", True, True, True),
        "pinky_01_r" : ("f_pinky.01.R", True, True, True),
        "pinky_02_r" : ("f_pinky.02.R", True, True, True),
        "pinky_03_r" : ("f_pinky.03.R", True, True, True),
        "ring_01_r" : ("f_ring.01.R", True, True, True),
        "ring_02_r" : ("f_ring.02.R", True, True, True),
        "ring_03_r" : ("f_ring.03.R", True, True, True),
        "thumb_01_r" : ("thumb.01.R", True, True, True),
        "thumb_02_r" : ("thumb.02.R", True, True, True),
        "thumb_03_r" : ("thumb.03.R", True, True, True),
        "neck_01" : ("neck", True, True, True),
        "head" : ("head_01", True, True, True),
        "thigh_l" : ("thigh_fk.L", True, True, True),
        "calf_l" : ("shin_fk.L", True, True, True),
        "foot_l" : ("foot_fk.L", True, True, True),
        "ball_l" : ("toe.L", True, True, True),
        "thigh_r" : ("thigh_fk.R", True, True, True),
        "calf_r" : ("shin_fk.R", True, True, True),
        "foot_r" : ("foot_fk.R", True, True, True),
        "ball_r" : ("toe.R", True, True, True),
        "upperarm_twist_01_l" : ("twist_01.upper_arm.L", True, True, True),
        "upperarm_twist_02_l" : ("upper_arm_tweak.L.001", False, False, False),
        "lowerarm_twist_01_l" : ("forearm_tweak.L.001", False, False, False),
        "lowerarm_twist_02_l" : ("forearm_tweak.L", False, False, False),
        "thigh_twist_01_l" : ("twist_01.thigh.L", False, False, False),
        "thigh_twist_02_l" : ("thigh_tweak.L.001", False, False, False),
        "calf_twist_01_l" : ("shin_tweak.L.001", False, False, False),
        "calf_twist_02_l" : ("shin_tweak.L", False, False, False),
        "upperarm_twist_01_r" : ("twist_01.upper_arm.R", True, True, True),
        "upperarm_twist_02_r" : ("upper_arm_tweak.R.001", False, False, False),
        "lowerarm_twist_01_r" : ("forearm_tweak.R.001", False, False, False),
        "lowerarm_twist_02_r" : ("forearm_tweak.R", False, False, False),
        "thigh_twist_01_r" : ("twist_01.thigh.R", False, False, False),
        "thigh_twist_02_r" : ("thigh_tweak.R.001", False, False, False),
        "calf_twist_01_r" : ("shin_tweak.R.001", False, False, False),
        "calf_twist_02_r" : ("shin_tweak.R", False, False, False),
        "ik_foot_root" : ("ik_foot_root", False, True, True),
        "ik_foot_l" : ("ik_foot_l", False, True, True),
        "ik_foot_r" : ("ik_foot_r", False, True, True),
        "ik_hand_root" : ("ik_hand_root", False, True, True),
        "ik_hand_gun" : ("ik_hand_gun", False, True, True),
        "ik_hand_l" : ("ik_hand_l", False, True, True),
        "ik_hand_r" : ("ik_hand_r", False, True, True)
    }
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def create_mapping(self, name):
        
        source = bpy.data.objects.get(self.source_name)
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        source.select_set(True)
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        ebones = source.data.edit_bones
        map = []
                
        for bone in ebones:
            if bone.name in self.mapping:
                tname, enabled, loc, rot = self.mapping[bone.name]
                map.append({'name':bone.name, 'control':tname, 'enabled':enabled, 'location': loc, 'rotation': rot})
        
        if bpy.data.texts.get(name) is None:
            bpy.data.texts.new(name)
        
        d_str = json.dumps(map, indent=2)
        bpy.data.texts[name].from_string(d_str)
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        return
        
    def execute(self, context):
        
        source = bpy.data.objects.get(self.source_name)
        
        if source is None:
            self.report({'ERROR'}, "Please select a source animation armature in Uefy Animation Tools.")
            return {'FINISHED'}
        
        name = "uefy_anim_Custom.json"
        self.create_mapping(name)
        
        return {'FINISHED'}
    
class UEFY_OT_load_anim_mapping(bpy.types.Operator):
    bl_idname = "uefy.load_anim_mapping"
    bl_label = "Load Mappings"
    bl_description = "Load default animation options"
    
    map_folder = 'mapping'
    
    def get_path(self, folder):
        
        script_file = os.path.realpath(__file__)
        directory = os.path.dirname(script_file)
        
        path = directory + os.sep + folder + os.sep
        path = bpy.path.native_pathsep(path)
        
        return path
    
    def load_file(self, path, filename):
        
        path = path + filename
        
        if not os.path.isfile(path):
            self.report('ERROR', "Invalid path provided for file: " + filename)
            return
        
        file = open(path, "r")
        data = json.load(file)
        file.close()
        
        if bpy.data.texts.get(filename) is None:
            bpy.data.texts.new(filename)
        
        d_str = json.dumps(data, indent=2)
        bpy.data.texts[filename].from_string(d_str)
        
        return
    
    def execute(self, context):
        
        path = self.get_path(self.map_folder)
        
        if os.path.isdir(path):
            for paths, dirs, files in os.walk(path):
                for file in files:
                    if file[-5:] == '.json' and file[:13] == 'uefy_anim_':
                        self.load_file(path, file)
        
        return {'FINISHED'}
    
class UEFY_OT_match_pose(bpy.types.Operator):
    bl_idname = "uefy.match_pose"
    bl_label = "Match Pose"
    bl_description = "Match pose from source armature"
    
    source_name : StringProperty()
    target_name : StringProperty()
    anim_mapping : StringProperty()
    
    mapping = []
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def process_location(self, s_name, t_name):
        
        source = bpy.data.objects.get(self.source_name)
        target = bpy.data.objects.get(self.target_name)
        
        s_bone = source.pose.bones[s_name]
        t_bone = target.pose.bones[t_name]
        
        c = t_bone.constraints.new(type='COPY_LOCATION')
        c.target = source
        c.subtarget = s_bone.name
        c.target_space = 'WORLD'
        c.owner_space = 'WORLD'
        
        bpy.context.view_layer.update()
        
        m = t_bone.matrix
        t_bone.constraints.remove(c)
        t_bone.matrix = m
        
        return
    
    def process_rotation(self, s_name, t_name):
        
        source = bpy.data.objects.get(self.source_name)
        target = bpy.data.objects.get(self.target_name)
        
        s_bone = source.pose.bones[s_name]
        t_bone = target.pose.bones[t_name]
        
        c = t_bone.constraints.new(type='COPY_ROTATION')
        c.target = source
        c.subtarget = s_bone.name
        c.target_space = 'WORLD'
        c.owner_space = 'WORLD'
        
        bpy.context.view_layer.update()
        
        m = t_bone.matrix
        t_bone.constraints.remove(c)
        t_bone.matrix = m
        
        return
    
    def match_root(self):
        
        source = bpy.data.objects.get(self.source_name)
        target = bpy.data.objects.get(self.target_name)
        
        t_bone = target.pose.bones['root']
        
        c = t_bone.constraints.new(type='COPY_LOCATION')
        c.target = source
        c.target_space = 'WORLD'
        c.owner_space = 'WORLD'
        
        bpy.context.view_layer.update()
        
        m = t_bone.matrix
        t_bone.constraints.remove(c)
        t_bone.matrix = m
        
        c = t_bone.constraints.new(type='COPY_ROTATION')
        c.target = source
        c.target_space = 'WORLD'
        c.owner_space = 'WORLD'
        
        bpy.context.view_layer.update()
        
        m = t_bone.matrix
        t_bone.constraints.remove(c)
        t_bone.matrix = m
        
        return
    
    def match_pivot(self):
        
        source = bpy.data.objects.get(self.source_name)
        target = bpy.data.objects.get(self.target_name)
        
        bpy.context.view_layer.update()
        
        s_bone = source.pose.bones['spine_01']
        t_bone = target.pose.bones['spine_01']
        t_control = target.pose.bones['torso']
        
        b = s_bone.tail.copy()
        a = t_bone.tail.copy()
        t = t_control.location.copy()
        
        m1 = source.matrix_world @ b
        m2 = target.matrix_world @ a
        m3 = target.matrix_world @ t
        
        t_control.location = m3 + m1 - m2
        
        bpy.context.view_layer.update()
        
        self.process_rotation(s_bone.name, 'spine_fk.001')
        
        self.process_location('spine_01', 'spine_fk')
        self.process_rotation('spine_01', 'spine_fk')
        
        return
    
    def process_map(self):
        
        source = bpy.data.objects.get(self.source_name)
        target = bpy.data.objects.get(self.target_name)
        
        for record in self.mapping:
            sname = record['name']
            tname = record['control']
            enabled = record['enabled']
            loc = record['location']
            rot = record['rotation']
            
            if sname == 'spine_01' or sname == 'pelvis':
                continue
            
            if enabled == True:
                if loc == True:
                    self.process_location(sname, tname)
                if rot == True:
                    self.process_rotation(sname, tname)
        
        return
    
    def execute(self, context):
        
        source = bpy.data.objects.get(self.source_name)
        target = bpy.data.objects.get(self.target_name)
        
        if source is None:
            self.report({'ERROR'}, "Please select a source animation armature in Uefy Animation Panel.")
            return {'FINISHED'}
        
        if target is None:
            self.report({'ERROR'}, 'Unable to find selected rig. Make sure Uefy Script Panel properties "Rig" is set correctly.')
            return {'FINISHED'}
        
        if self.anim_mapping == '0':
            self.report({'ERROR'}, 'Select a mapping in "Animation Pose Matching" before running this operator')
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        source.select_set(False)
        target.select_set(True)
        bpy.ops.object.mode_set(mode = 'POSE')
        
        map = bpy.data.texts[self.anim_mapping].as_string()
        self.mapping = json.loads(map)
        
        self.match_root()
        self.match_pivot()
        
        self.process_map()
        
        bpy.context.view_layer.update()
        
        return {'FINISHED'}
    
class UEFY_OT_match_multi_frame(bpy.types.Operator):
    bl_idname = "uefy.match_multi_frame"
    bl_label = "Multi Frame Match"
    bl_description = "Match multiple frames"
    
    source_name : StringProperty()
    target_name : StringProperty()
    anim_mapping : StringProperty()
    start_frame : IntProperty()
    end_frame : IntProperty()
    key_mode : StringProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def execute(self, context):
        
        source = bpy.data.objects.get(self.source_name)
        target = bpy.data.objects.get(self.target_name)
        
        if source is None:
            self.report({'ERROR'}, "Please select a source animation armature in Uefy Animation Panel.")
            return {'FINISHED'}
        
        if target is None:
            self.report({'ERROR'}, 'Unable to find selected rig. Make sure Uefy Script Panel properties "Rig" is set correctly.')
            return {'FINISHED'}
        
        if self.anim_mapping == '0':
            self.report({'ERROR'}, 'Select a mapping in "Animation Pose Matching" before running this operator')
            return {'FINISHED'}
        
        if int(self.start_frame) > int(self.end_frame):
            self.report({'ERROR'}, 'End frame number must be greater than Start frame number')
            return {'FINISHED'}
        
        if target.animation_data.action is None:
            self.report({'ERROR'}, f"Select an 'Action' in Dope Sheet -> Action Editor for '{target.name}' object before using this operator")
            return {'FINISHED'}
        
        for i in range(self.start_frame, self.end_frame + 1):
            
            bpy.data.scenes[bpy.context.window.scene.name].frame_set(i)
            bpy.ops.uefy.match_pose(source_name=self.source_name, target_name=self.target_name, anim_mapping=self.anim_mapping)
            
            if self.key_mode == "0":
                bpy.ops.anim.keyframe_insert_menu(type='WholeCharacter')
            else:
                bpy.ops.anim.keyframe_insert_menu(type='WholeCharacterSelected')

        return {'FINISHED'}
    
    
classes = ( UEFY_OT_match_pose, UEFY_OT_scan_anim,
            UEFY_OT_load_anim_mapping, UEFY_OT_match_multi_frame)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    
def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
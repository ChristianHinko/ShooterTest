"""
Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq
https://www.rakiz.com

Created by Rakiz Farooq

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

"""
Uefy 2 is an addon for Blender that provides tools to make Rigify rigs 
suitable for use in game engines.

This addon is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support 
this project and help ensure continued development.
"""
import bpy
import json
import os

from bpy.props import StringProperty

class UEFY_OT_scan(bpy.types.Operator):
    bl_idname = "uefy.scan"
    bl_label = "Scan Skeleton"
    bl_description = "Preprocess the Skeleton"
    
    metarig_name : StringProperty()
    
    BoneMap = {}
    
    def process_chain(self, pbone, base_name):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        pbones = metarig.pose.bones
        
        for child in pbone.children:
            if child.rigify_type == "":
                self.BoneMap[base_name].append({child.name : child.parent.name})
                self.process_chain(child, base_name)
        
        return
    
    def build_map(self):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        pbones = metarig.pose.bones
        
        for name in self.BoneMap:
            self.process_chain(pbones[name], name)
        
        return
    
    def build_type_map(self):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        pbones = metarig.pose.bones
                
        for bone in pbones:
            if bone.rigify_type != "":
                if bone.name not in self.BoneMap:
                    parent_name = "root"
                    if bone.parent:
                        parent_name = bone.parent.name
                    self.BoneMap[bone.name] = [{bone.name : parent_name}]
        
        return
    
    def find_palm(self, b, p, type):
        
        token = b.split('.')[0]
        
        limb = []
        extras = []
        indexes = []
        
        for record in self.BoneMap[type]:
            for k, v in record.items():
                if k.split('.')[0] != token:
                    extras.append({k,v})
                else:
                    limb.append({k:v})
                    indexes.append(self.BoneMap[type].index(record))
        
        return limb, indexes, type
    
    def update_palm(self, palm, indexes, type, old):
        
        for i in sorted(indexes, reverse=True):
            del self.BoneMap[old][i]
        
        self.BoneMap[type].extend(palm)
        
        return
    
    def fix_palm(self, source):
        
        record = self.BoneMap[source][0]
        for b, p in record.items():
            break
                
        for type in self.BoneMap:
            for record in self.BoneMap[type]:
                for k, v in record.items():
                    if k == p:
                        palm, indexes, old = self.find_palm(b, p, type)
                        break
        
        self.update_palm(palm, indexes, b, old)
        
        return
    
    def fix_map(self):
        metarig = bpy.data.objects.get(self.metarig_name)
        pbones = metarig.pose.bones
        
        for type in self.BoneMap:
            if pbones[type].rigify_type == 'limbs.super_palm':
                self.fix_palm(type)
        
        return
    
    def execute(self, context):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        if metarig is None:
            self.report({'ERROR'}, "Metarig is not set in Uefy Script Panel")
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        self.BoneMap = {}
        
        self.build_type_map()
        self.build_map()
        self.fix_map()
        
        if bpy.data.texts.get("uefy_bonemap.json") is None:
            bpy.data.texts.new("uefy_bonemap.json")
        
        d_str = json.dumps(self.BoneMap, indent=2)
        bpy.data.texts["uefy_bonemap.json"].from_string(d_str)
        
        bpy.ops.object.mode_set(mode='OBJECT')
        
        #try:
        #    bpy.ops.uefy.verify_map(metarig_name=self.metarig_name)
        #except RuntimeError as ex:
        #    self.report({'ERROR'}, ex.args[0])
        
        bpy.ops.uefy.auto_fix_map(metarig_name=self.metarig_name)
        
        return {'FINISHED'}
    
class UEFY_OT_auto_fix_map(bpy.types.Operator):
    bl_idname = "uefy.auto_fix_map"
    bl_label = "Auto Fix Map"
    bl_description = "Auto fix default bonemap"
    
    metarig_name : StringProperty()
    
    BoneMap = {}
    palms = []
    
    def process_level(self, name):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        pbones = metarig.pose.bones
        
        level = 0
        
        if pbones[name].rigify_type != "":
            level = level + 1
        
        for parent in pbones[name].parent_recursive:
            is_palm = True if parent.name in self.palms else False
            
            if parent.rigify_type != "" or is_palm:
                level = level + 1
        
        return level
    
    def execute(self, context):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        map = bpy.data.texts["uefy_bonemap.json"].as_string()
        self.BoneMap = json.loads(map)
        
        pbones = metarig.pose.bones
        
        palm_samples = []
        for name in self.BoneMap:
            if pbones[name].rigify_type == "limbs.super_palm":
                palm_samples.append(name)
                
        for pname in palm_samples:
            for record in self.BoneMap[pname]:
                for k,v in record.items():
                    self.palms.append(k)
        
        samples = {}
        
        for name in self.BoneMap:
            lvl = self.process_level(name)
            samples[name] = lvl
        
        sorted_samples = sorted(samples.items(), key=lambda x: x[1], reverse = False)
        
        updated = {}
        
        for k,v in sorted_samples:
            if k in self.BoneMap:
                updated[k] = self.BoneMap[k]
        
        if bpy.data.texts.get("uefy_bonemap.json") is None:
            bpy.data.texts.new("uefy_bonemap.json")
        
        d_str = json.dumps(updated, indent=2)
        bpy.data.texts["uefy_bonemap.json"].from_string(d_str)
        
        return {'FINISHED'}
    
class UEFY_OT_verify_map(bpy.types.Operator):
    bl_idname = "uefy.verify_map"
    bl_label = "Load Mappings"
    bl_description = "Load default mappings for different types of characters"
    
    metarig_name : StringProperty()
    
    BoneMap = {}
    previous = []
    
    def add_processed(self, name):
        
        for record in self.BoneMap[name]:
            for k, v in record.items():
                if k not in self.previous:
                    self.previous.append(k)
        
        return
    
    def execute(self, context):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        if metarig is None:
            self.report({'ERROR'}, "Metarig is not set in Uefy Script Panel")
            return {'FINISHED'}
        
        if bpy.data.texts.get("uefy_bonemap.json") is None:
            self.report({'ERROR'}, "No map file found. Run 'Preprocess' to create one first.")
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        map = bpy.data.texts["uefy_bonemap.json"].as_string()
        self.BoneMap = json.loads(map)
        
        self.previous = []
        
        success = True
        
        for name in self.BoneMap:
            parent = self.BoneMap[name][0][name]
            if parent == 'root':
                self.add_processed(name)
                continue
            if parent not in self.previous:
                success = False
                break
            self.add_processed(name)
        
        if success == False:
            self.report({'ERROR'}, "'"+ parent +"' must be added to metarig before '"+ name +"'.  You have to build the metarig in the correct order from root upward.")
        else:
            self.report({'INFO'}, "Preprocess Success")
        
        return {'FINISHED'}
    
class UEFY_OT_load_mapping(bpy.types.Operator):
    bl_idname = "uefy.load_mapping"
    bl_label = "Load Mappings"
    bl_description = "Load default mappings for different types of characters"
    
    map_folder = 'mapping'
    
    def get_path(self, folder):
        
        script_file = os.path.realpath(__file__)
        directory = os.path.dirname(script_file)
        
        path = directory + os.sep + folder + os.sep
        path = bpy.path.native_pathsep(path)
        
        return path
    
    def load_file(self, path, filename):
        
        path = path + filename
        
        if not os.path.isfile(path):
            self.report('ERROR', "Invalid path provided for file: " + filename)
            return
        
        file = open(path, "r")
        data = json.load(file)
        file.close()
        
        if bpy.data.texts.get(filename) is None:
            bpy.data.texts.new(filename)
        
        d_str = json.dumps(data, indent=2)
        bpy.data.texts[filename].from_string(d_str)
        
        return
    
    def execute(self, context):
        
        path = self.get_path(self.map_folder)
        
        if os.path.isdir(path):
            for paths, dirs, files in os.walk(path):
                for file in files:
                    if file[-5:] == '.json' and file[:13] == 'uefy_mapping_':
                        self.load_file(path, file)
        
        return {'FINISHED'}
    
    
classes = ( UEFY_OT_scan, UEFY_OT_verify_map, UEFY_OT_auto_fix_map, UEFY_OT_load_mapping )
    
def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    
    
def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
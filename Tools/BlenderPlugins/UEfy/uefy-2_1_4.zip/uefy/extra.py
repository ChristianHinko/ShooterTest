"""
Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq
https://www.rakiz.com

Created by Rakiz Farooq

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

"""
Uefy 2 is an addon for Blender that provides tools to make Rigify rigs 
suitable for use in game engines.

This addon is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support 
this project and help ensure continued development.
"""
import bpy
import json
import mathutils
import os
import addon_utils

from math import radians
from math import isclose
from mathutils import Color
from bpy.props import StringProperty
from bpy.props import BoolProperty
from bpy.props import IntProperty

class UEFY_OT_fix_mannequin(bpy.types.Operator):
    bl_idname = "uefy.fix_mannequin"
    bl_label = "Fix Mannequin"
    bl_description = "Fix the feet bone of the Unreal Mannequin after import"
    
    uemann_name : StringProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def execute(self, context):
        
        uemann = bpy.data.objects.get(self.uemann_name)
        if uemann is None:
            self.report({'ERROR'}, 'Invalid Target: Please Set UE Mann armature in properties.')
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        bpy.context.view_layer.objects.active = uemann
        uemann.select_set(True)

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        
        ebones = uemann.data.edit_bones
        
        foot_l = ebones.get("foot_l")
        ball_l = ebones.get("ball_l")
        
        if foot_l is None or ball_l is None:
            self.report({'ERROR'}, 'This operator only works on UE Mannequin. Only use once.')
            return {'FINISHED'}
        
        for window in bpy.context.window_manager.windows:
            screen = window.screen
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    override = context.copy()
                    override['window'] = window
                    override['screen'] = screen
                    override['area'] = area
                    break
        
        ball_l.select_head = True
        
        bpy.ops.view3d.snap_cursor_to_selected(override)
        context.scene.tool_settings.transform_pivot_point = 'CURSOR'
        
        ball_l.select = True
        ball_l.select_head = True
        ball_l.select_tail = True
        
        if bpy.app.version >= (2, 90, 0):
            rotation = radians(90)
        else:
            rotation = radians(-90)
        
        bpy.ops.transform.rotate(value = rotation, orient_axis='X')
        bpy.ops.view3d.snap_selected_to_cursor(override, use_offset=False)
        
        bpy.ops.armature.select_all(action='DESELECT')
        
        foot_l.select_tail = True
        
        bpy.ops.view3d.snap_selected_to_cursor(override)
        foot_l.roll = radians(-10)
        
        if not isclose(context.scene.unit_settings.scale_length, 0.01, abs_tol=0.001):
            self.report({'ERROR'}, "WARNING: World unit scale is not 0.01")
        ball_l.length = 0.072988 * 100
        
        bpy.ops.armature.select_all(action='DESELECT')
        
        ball_l.select = True
        ball_l.select_head = True
        ball_l.select_tail = True
        
        foot_l.select = True
        foot_l.select_head = True
        foot_l.select_tail = True
        
        bpy.ops.armature.symmetrize()
        bpy.ops.view3d.snap_cursor_to_center(override)
        
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'
        
        return {'FINISHED'}
        
class UEFY_OT_skin_scan_armature(bpy.types.Operator):
    bl_idname = "uefy.skin_scan_armature"
    bl_label = "Scan Armature"
    bl_description = "Scan armature to update deform bone names"
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def create_mapping(self, target, name):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        target.select_set(True)
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        ebones = target.data.edit_bones
        map = []
        
        for bone in ebones:
            if bone.use_deform == True:
                map.append({bone.name:bone.name})
        
        if bpy.data.texts.get(name) is None:
            bpy.data.texts.new(name)
        
        d_str = json.dumps(map, indent=2)
        bpy.data.texts[name].from_string(d_str)
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        return
    
    def execute(self, context):
        
        target = context.armature
        self.create_mapping(context.object, "uefy_skin_Custom.json")
        
        return {'FINISHED'}
        
class UEFY_OT_skin_apply(bpy.types.Operator):
    bl_idname = "uefy.skin_apply"
    bl_label = "Apply Skin"
    bl_description = "Rename bones according to selected skin"
    
    skin_mapping : StringProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature
        
    def execute(self, context):
        
        if self.skin_mapping == '0':
            self.report({'ERROR'}, 'Invalid Selection: Please select a skin group from the dropdown')
            return {'FINISHED'}
        
        if bpy.data.texts[self.skin_mapping] is None:
            self.report({'ERROR'}, 'Can not find skin mapping json file ' + self.skin_mapping)
            return {'FINISHED'}
        
        target = context.armature
        
        if target is None:
            self.report({'ERROR'}, 'Please select an armature before running this operator.')
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        ebones = target.edit_bones
        
        str = bpy.data.texts[self.skin_mapping].as_string()
        map = json.loads(str)
        
        for record in map:
            for k, v in record.items():
                bone = ebones.get(k)
                if bone is not None:
                    bone.name = v
                else:
                    self.report({'WARNING'}, 'Skipping: Bone not found: ' + k)
        
        bpy.context.view_layer.update()
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        return {'FINISHED'}
        
class UEFY_OT_skin_scan_vgs(bpy.types.Operator):
    bl_idname = "uefy.skin_scan_vgs"
    bl_label = "Scan Vertex Groups"
    bl_description = "Scan vertex groups to update bone names"
    
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def execute(self, context):
        
        map = []
        
        for ob in context.object.children:
            if ob.type == 'MESH':
                for vg in ob.vertex_groups:
                    if vg.name not in map:
                        map.append({vg.name:vg.name})
        
        name = "uefy_vgs_Custom.json"
        
        if bpy.data.texts.get(name) is None:
            bpy.data.texts.new(name)
        
        d_str = json.dumps(map, indent=2)
        bpy.data.texts[name].from_string(d_str)
        
        return {'FINISHED'}
        
class UEFY_OT_vgs_apply(bpy.types.Operator):
    bl_idname = "uefy.vgs_apply"
    bl_label = "Apply Vertex Groups"
    bl_description = "Rename vertex groups according to selected mapping"
    
    vgs_mapping : StringProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature
        
    def execute(self, context):
        
        if self.vgs_mapping == '0':
            self.report({'ERROR'}, 'Invalid Selection: Please select a vertex group mapping from the dropdown')
            return {'FINISHED'}
        
        if bpy.data.texts[self.vgs_mapping] is None:
            self.report({'ERROR'}, 'Can not find vertex group mapping json file ' + self.vgs_mapping)
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        str = bpy.data.texts[self.vgs_mapping].as_string()
        map = json.loads(str)
        
        data = {}
        
        for record in map:
            for k, v in record.items():
                data[k] = v
        
        for ob in context.object.children:
            if ob.type == 'MESH':
                for vg in ob.vertex_groups:
                    if vg.name in data.keys():
                        vg.name = data[vg.name]
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        return {'FINISHED'}
        
class UEFY_OT_load_vgs(bpy.types.Operator):
    bl_idname = "uefy.load_vgs"
    bl_label = "Load Vertex Groups"
    bl_description = "Load default mappings for different vertex groups"
    
    map_folder = 'mapping'
    
    def get_path(self, folder):
        
        script_file = os.path.realpath(__file__)
        directory = os.path.dirname(script_file)
        
        path = directory + os.sep + folder + os.sep
        path = bpy.path.native_pathsep(path)
        
        return path
    
    def load_file(self, path, filename):
        
        path = path + filename
        
        if not os.path.isfile(path):
            self.report('ERROR', "Invalid path provided for file: " + filename)
            return
        
        file = open(path, "r")
        data = json.load(file)
        file.close()
        
        if bpy.data.texts.get(filename) is None:
            bpy.data.texts.new(filename)
        
        d_str = json.dumps(data, indent=2)
        bpy.data.texts[filename].from_string(d_str)
        
        return
    
    def execute(self, context):
        
        path = self.get_path(self.map_folder)
        
        if os.path.isdir(path):
            for paths, dirs, files in os.walk(path):
                for file in files:
                    if file[-5:] == '.json' and file[:9] == 'uefy_vgs_':
                        self.load_file(path, file)
        
        return {'FINISHED'}
        
class UEFY_OT_load_skins(bpy.types.Operator):
    bl_idname = "uefy.load_skins"
    bl_label = "Load Skins"
    bl_description = "Load default mappings for different skins"
    
    map_folder = 'mapping'
    
    def get_path(self, folder):
        
        script_file = os.path.realpath(__file__)
        directory = os.path.dirname(script_file)
        
        path = directory + os.sep + folder + os.sep
        path = bpy.path.native_pathsep(path)
        
        return path
    
    def load_file(self, path, filename):
        
        path = path + filename
        
        if not os.path.isfile(path):
            self.report('ERROR', "Invalid path provided for file: " + filename)
            return
        
        file = open(path, "r")
        data = json.load(file)
        file.close()
        
        if bpy.data.texts.get(filename) is None:
            bpy.data.texts.new(filename)
        
        d_str = json.dumps(data, indent=2)
        bpy.data.texts[filename].from_string(d_str)
        
        return
    
    def execute(self, context):
        
        path = self.get_path(self.map_folder)
        
        if os.path.isdir(path):
            for paths, dirs, files in os.walk(path):
                for file in files:
                    if file[-5:] == '.json' and file[:10] == 'uefy_skin_':
                        self.load_file(path, file)
        
        return {'FINISHED'}
        
class UEFY_OT_bone_rename(bpy.types.Operator):
    bl_idname = "uefy.bone_rename"
    bl_label = "Rename Bones"
    bl_description = "Rename Selected Bone Chain"
    
    limb_type : bpy.props.IntProperty()
    
    spine = ["pelvis", "spine_01", "spine_02", "spine_03", "neck_01", "head"]
    leg_l = ["thigh_l", "calf_l", "foot_l", "ball_l"]
    arm_l = ["clavicle_l", "upperarm_l", "lowerarm_l", "hand_l"]
    f_index_l = ["index_01_l", "index_02_l", "index_03_l"]
    f_middle_l = ["middle_01_l", "middle_02_l", "middle_03_l"]
    f_ring_l = ["ring_01_l", "ring_02_l", "ring_03_l"]
    f_pinky_l = ["pinky_01_l", "pinky_02_l", "pinky_03_l"]
    f_thumb_l = ["thumb_01_l", "thumb_02_l", "thumb_03_l"]
    leg_r = ["thigh_r", "calf_r", "foot_r", "ball_r"]
    arm_r = ["clavicle_r", "upperarm_r", "lowerarm_r", "hand_r"]
    f_index_r = ["index_01_r", "index_02_r", "index_03_r"]
    f_middle_r = ["middle_01_r", "middle_02_r", "middle_03_r"]
    f_ring_r = ["ring_01_r", "ring_02_r", "ring_03_r"]
    f_pinky_r = ["pinky_01_r", "pinky_02_r", "pinky_03_r"]
    f_thumb_r = ["thumb_01_r", "thumb_02_r", "thumb_03_r"]
    
    
    @classmethod
    def poll(cls, context):
        return context.armature and context.mode == 'EDIT_ARMATURE'
        
    def update_names(self, bone, names, i=0):
        
        if i >= len(names):
            return
        
        bone.name = names[i]
        i = i + 1
        
        if len(bone.children) < 1:
            return
        
        child = bone.children[0]
        self.update_names(child, names, i)
        
        return
    
    def execute(self, context):
        
        bone = context.selected_editable_bones[0]
        
        if self.limb_type == 0:
            self.update_names(bone, self.spine)
        elif self.limb_type == 1:
            self.update_names(bone, self.leg_l)
        elif self.limb_type == 2:
            self.update_names(bone, self.arm_l)
        elif self.limb_type == 3:
            self.update_names(bone, self.f_index_l)
        elif self.limb_type == 4:
            self.update_names(bone, self.f_middle_l)
        elif self.limb_type == 5:
            self.update_names(bone, self.f_ring_l)
        elif self.limb_type == 6:
            self.update_names(bone, self.f_pinky_l)
        elif self.limb_type == 7:
            self.update_names(bone, self.f_thumb_l)
        elif self.limb_type == 8:
            self.update_names(bone, self.leg_r)
        elif self.limb_type == 9:
            self.update_names(bone, self.arm_r)
        elif self.limb_type == 10:
            self.update_names(bone, self.f_index_r)
        elif self.limb_type == 11:
            self.update_names(bone, self.f_middle_r)
        elif self.limb_type == 12:
            self.update_names(bone, self.f_ring_r)
        elif self.limb_type == 13:
            self.update_names(bone, self.f_pinky_r)
        elif self.limb_type == 14:
            self.update_names(bone, self.f_thumb_r)
        
        return {'FINISHED'}
    
class UEFY_OT_rig_name(bpy.types.Operator):
    bl_idname = "uefy.rig_name"
    bl_label = "Rig Name"
    bl_description = "Change selected rig name"
    
    export : BoolProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def execute(self, context):
        
        target = context.object
        
        if self.export:
            target.name = "Armature"
        else:
            target.name = "rig"
        
        return {'FINISHED'}
    
class UEFY_OT_force_rest_pose(bpy.types.Operator):
    bl_idname = "uefy.force_rest_pose"
    bl_label = "Force Rest Pose"
    bl_description = "Force Update 'Pose' to 'Rest Pose' for mesh and armature"
    
    export : BoolProperty()
    
    @classmethod
    def poll(cls, context):
        return context.object and context.mode == "OBJECT" and context.object.type == "MESH"
    
    def detach_mesh(self, context, object):
        
        override = context.copy()
        override["object"] = object
        
        version = bpy.app.version
        
        for mod in object.modifiers:
            if mod.type == "ARMATURE":
                if version >= (2, 90, 0):
                    bpy.ops.object.modifier_apply(override, modifier=mod.name)
                else:
                    bpy.ops.object.modifier_apply(override, apply_as='DATA', modifier=mod.name)
                break
        
        return
    
    def attach_mesh(self, object, rig):
        
        mod = object.modifiers.new("rig", "ARMATURE")
        mod.object = rig
        
        return
    
    def execute(self, context):
        
        target = context.object
        rig = target.parent
        
        if rig is None or rig.type != "ARMATURE":
            self.report({'ERROR'}, "Mesh must be attached to an armature.")
            return {'FINISHED'}
        
        meshes = []
        
        for object in rig.children:
            if object.type == "MESH":
                meshes.append(object)
        
        for mesh in meshes:
            self.detach_mesh(context, mesh)
        
        bpy.ops.object.select_all(action='DESELECT')
        
        context.view_layer.objects.active = rig
        rig.select_set(True)
        
        bpy.context.view_layer.update() 
        bpy.ops.object.mode_set(mode = 'POSE')
        bpy.ops.pose.armature_apply(selected=False)
        
        for mesh in meshes:
            self.attach_mesh(mesh, rig)
        
        return {'FINISHED'}
    
class UEFY_OT_extract_mesh(bpy.types.Operator):
    bl_idname = "uefy.extract_mesh"
    bl_label = "Extract Mesh"
    bl_description = "Separates mesh from armature to a standalone object"
    
    all_meshes : BoolProperty()
    
    @classmethod
    def poll(cls, context):
        return context.object and context.mode == "OBJECT" and context.object.type == "MESH"
    
    def process_mesh(self, context, mesh):
        
        override = context.copy()
        override["object"] = mesh
        
        version = bpy.app.version
        
        for mod in mesh.modifiers:
            if mod.type == "ARMATURE":
                if version >= (2, 90, 0):
                    bpy.ops.object.modifier_apply(override, modifier=mod.name)
                else:
                    bpy.ops.object.modifier_apply(override, apply_as='DATA', modifier=mod.name)
        
        mesh.parent = None
        
        return
    
    def execute(self, context):
        
        mesh = context.object
        rig = mesh.parent
        
        if rig.type != "ARMATURE":
            self.report('ERROR', "Selected mesh must be child of an armature")
            return {'FINISHED'}
        
        meshes = []
        
        if self.all_meshes:
            for object in rig.children:
                if object.type == "MESH":
                    meshes.append(object)
            
            for mesh in meshes:
                bpy.ops.object.select_all(action='DESELECT')
                self.process_mesh(context, mesh)
            
        else:
            self.process_mesh(context, mesh)
            
        return {'FINISHED'}
    
class UEFY_OT_mirror_weights(bpy.types.Operator):
    bl_idname = "uefy.mirror_weights"
    bl_label = "Mirror Bone Weights"
    bl_description = "Mirror Bone Weights from Left Side to Right Side"
    
    mirror_type : bpy.props.IntProperty()
    use_topology : bpy.props.BoolProperty()
    
    @classmethod
    def poll(cls, context):
        return context.mode == 'PAINT_WEIGHT'

    def process_vg(self, vgs, main, flip):
        
        vg_flip = vgs.get(flip)
        if vg_flip is not None:
            vgs.remove(vg_flip)
        
        bpy.ops.object.vertex_group_set_active(group=main)
        bpy.ops.object.vertex_group_copy()
        bpy.ops.object.vertex_group_mirror(use_topology=self.use_topology)
        
        vgs.active.name = flip
        
        return
    
    def mirror_active(self, context):
        print("Mirror Active Bone")
        
        vgs = context.object.vertex_groups
        
        if len(vgs.active.name) < 3:
            self.report({'ERROR'}, 'Selected bone name is too short. Must end in _l or _r')
            return
        
        name = vgs.active.name[:-2]
        suffix = vgs.active.name[-2:]
        
        if suffix == '_l':
            main = name + '_l'
            flip = name + '_r'
        elif suffix == '_r':
            main = name + '_r'
            flip = name + '_l'
        else:
            self.report({'ERROR'}, 'Selected bone name must end in _l or _r')
            return
        
        self.process_vg(vgs, main, flip)
        
        return
    
    def mirror_all_l_to_r(self, context):
        
        vgs = context.object.vertex_groups
        for vg in vgs:
            if len(vg.name) < 3:
                continue
            if vg.name[-2:] == '_l':
                flip = vg.name[:-2] + '_r'
                self.process_vg(vgs, vg.name, flip)
        
        return
    
    def mirror_all_r_to_l(self, context):
        
        vgs = context.object.vertex_groups
        for vg in vgs:
            if len(vg.name) < 3:
                continue
            if vg.name[-2:] == '_r':
                flip = vg.name[:-2] + '_l'
                self.process_vg(vgs, vg.name, flip)
        
        return

    def execute(self, context):
        
        print("Mirror Bone Weights")
        
        if self.mirror_type == 0:
            self.mirror_active(context)
        elif self.mirror_type == 1:
            self.mirror_all_l_to_r(context)
        elif self.mirror_type == 2:
            self.mirror_all_r_to_l(context)
        
        dg = bpy.context.evaluated_depsgraph_get()
        dg.update()
        
        return {'FINISHED'}
    
classes = ( UEFY_OT_fix_mannequin, UEFY_OT_skin_scan_armature, UEFY_OT_skin_apply, UEFY_OT_skin_scan_vgs,
            UEFY_OT_vgs_apply, UEFY_OT_load_skins, UEFY_OT_load_vgs, UEFY_OT_bone_rename, 
            UEFY_OT_rig_name, UEFY_OT_force_rest_pose, UEFY_OT_extract_mesh,
            UEFY_OT_mirror_weights)
    
def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    
def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    
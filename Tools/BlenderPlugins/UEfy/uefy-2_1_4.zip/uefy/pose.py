"""
Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq
https://www.rakiz.com

Created by Rakiz Farooq

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

"""
Uefy 2 is an addon for Blender that provides tools to make Rigify rigs 
suitable for use in game engines.

This addon is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support 
this project and help ensure continued development.
"""
import bpy
import json
import math
import mathutils

from math import isclose
from bpy.props import StringProperty
from bpy.props import BoolProperty

axis_types = [
                ('0', '+ x-axis', 'Align to positive X-Axis'),
                ('1', '- x-axis', 'Align to negative X-Axis'),
                ('2', '+ z-axis', 'Align to positive Z-Axis'),
                ('3', '- z-axis', 'Align to negative Z-Axis')]

DeformLayers = [ 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False, 
    True, False, False, False, False, False, False, False
]

FaceLayers = [ 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False, 
    False, True, False, False, False, False, False, False
]

IKLayers = [ 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False, 
    False, False, True, False, False, False, False, False
]

TweakArmLeftLayers = [
    False, False, False, False, False, False, False, False, 
    False, True, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False
]

TweakArmRightLayers = [
    False, False, False, False, False, False, False, False, 
    False, False, False, False, True, False, False, False, 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False
]

TweakLegLeftLayers = [
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, True, 
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False
]

TweakLegRightLayers = [
    False, False, False, False, False, False, False, False, 
    False, False, False, False, False, False, False, False, 
    False, False, True, False, False, False, False, False, 
    False, False, False, False, False, False, False, False
]

class UEFY_OT_auto_roll_bones(bpy.types.Operator):
    bl_idname = "uefy.auto_roll_bones"
    bl_label = "Auto update rolls on character bones. Assumes symmetrical character!"
    bl_description = "Auto Roll Bones"
    
    target_name : StringProperty()
    
    main = ["pelvis", "spine_01", "spine_02", "spine_03", "neck_01", "head", "thigh_l", "calf_l", 
            "clavicle_l", "upperarm_l", "lowerarm_l", ]
    foot = ["foot_l", "ball_l"]
    hand = ["hand_l", "index_01_l", "index_02_l", "index_03_l", "middle_01_l", "middle_02_l", "middle_03_l",
            "ring_01_l", "ring_02_l", "ring_03_l", "pinky_01_l", "pinky_02_l", "pinky_03_l",
            "thumb_01_l", "thumb_02_l", "thumb_03_l"]
    
    def get_axis(self, bone, index):
        if index == 0:
            return bone.x_axis
        elif index == 1:
            return bone.x_axis * -1.0
        elif index == 2:
            return bone.z_axis
        elif index == 3:
            return bone.z_axis * -1.0
    
    def get_axis_index(self, x, z):
        v1 = abs(abs(x) - 1)
        v2 = abs(abs(z) - 1)
        
        if v1 <= v2:
            return 0 if x >= 0 else 1
        else:
            return 2 if z >= 0 else 3
    
    def roll_bone(self, name, basis):
        
        target = bpy.data.objects.get(self.target_name)
        ebones = target.data.edit_bones
        
        bone = ebones.get(name)
        
        if bone is None:
            self.report({'WARNING'}, 'Skipping: Could not find: ' + name)
            return
        
        if bone.name[:6] == "thumb_":
            basis = mathutils.Vector([0.7, 0.7, 0])
        
        x = bone.x_axis.dot(basis)
        z = bone.z_axis.dot(basis)
        
        index = self.get_axis_index(x, z)
        vec = self.get_axis(bone, index)
        
        UEFY_FUNC_align_x_axis(bone, vec)
        
        return
    
    def select_bone(self, name, ebones):
        
        bone = ebones.get(name)
        if bone is not None:
            bone.select = True
            bone.select_head = True
            bone.select_tail = True
        
        return
    
    def execute(self, context):
        
        target = bpy.data.objects.get(self.target_name)
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        ebones = target.data.edit_bones
        
        X = mathutils.Vector([1,0,0])
        Y = mathutils.Vector([0,1,0])
        Z = mathutils.Vector([0,0,1])
        
        for bone in self.main:
            self.roll_bone(bone, Y)
        
        for bone in self.hand:
            self.roll_bone(bone, Z * -1.0)
        
        self.roll_bone('foot_l', X)
        self.roll_bone('ball_l', Z)
        
        bpy.ops.armature.select_all(action='DESELECT')
        
        chains = []
        chains.extend(self.main)
        chains.extend(self.hand)
        chains.extend(self.foot)
        
        for name in chains:
            self.select_bone(name, ebones)
        
        bpy.ops.armature.symmetrize()
        bpy.ops.armature.select_all(action='DESELECT')
        
        self.report({'INFO'}, 'Success. Make sure to manually check hand bones rolls e.g. thumbs!')
        
        return {'FINISHED'}

class UEFY_OT_rename_bones(bpy.types.Operator):
    bl_idname = "uefy.rename_bones"
    bl_label = "Rename Bones"
    bl_description = "Rename bones according to selected mapping"
    
    target_name : StringProperty()
    character_mapping : StringProperty()
    
    def execute(self, context):
        
        if self.character_mapping == '0':
            self.report({'ERROR'}, 'Invalid Selection: Please select a character mapping from the Uefy Script Panel character operators section')
            return {'FINISHED'}
        
        if bpy.data.texts[self.character_mapping] is None:
            self.report({'ERROR'}, 'Can not find character mapping json file ' + self.character_mapping)
            return {'FINISHED'}
        
        target = bpy.data.objects.get(self.target_name)
        
        if target is None:
            self.report({'ERROR'}, 'Unable to find selected character armature. Make sure Uefy Script Panel properties "Character" is set correctly.')
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        ebones = target.data.edit_bones
        
        str = bpy.data.texts[self.character_mapping].as_string()
        map = json.loads(str)
        
        for record in map:
            for k, v in record.items():
                bone = ebones.get(k)
                if bone is not None:
                    ebones[k].name = v
        
        bpy.context.view_layer.update()
        
        return {'FINISHED'}

class UEFY_OT_scan_character(bpy.types.Operator):
    bl_idname = "uefy.scan_character"
    bl_label = "Prepare Mapping for selected character"
    bl_description = "Scan"
    
    character_name : StringProperty()
    
    def create_mapping(self, rig, name):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        rig.select_set(True)
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        ebones = rig.data.edit_bones
        map = []
        
        for bone in ebones:
            map.append({bone.name:bone.name})
        
        if bpy.data.texts.get(name) is None:
            bpy.data.texts.new(name)
        
        d_str = json.dumps(map, indent=2)
        bpy.data.texts[name].from_string(d_str)
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        return
    
    def execute(self, context):
        
        character = bpy.data.objects.get(self.character_name)
        
        if character is None:
            self.report({'ERROR'}, "Character is not set in Uefy Script Panel properties")
            return {'FINISHED'}
        
        self.create_mapping(character, "uefy_mapping_Custom.json")
        
        return {'FINISHED'}
        
# Based on stackexchange answer
# attribution url: https://blender.stackexchange.com/questions/76222/how-to-match-bone-orientation-between-two-objects-in-python
def UEFY_FUNC_align_x_axis(edit_bone, new_x_axis_input):
    new_x_axis = new_x_axis_input.copy()
    new_x_axis = new_x_axis.cross(edit_bone.y_axis)
    new_x_axis.normalize()
    dot = max(-1.0, min(1.0, edit_bone.z_axis.dot(new_x_axis)))
    angle = math.acos(dot)
    edit_bone.roll += angle
    dot1 = edit_bone.z_axis.dot(new_x_axis)
    edit_bone.roll -= angle * 2.0
    dot2 = edit_bone.z_axis.dot(new_x_axis)
    if dot1 > dot2:
        edit_bone.roll += angle * 2.0
        
class UEFY_OT_pose_character(bpy.types.Operator):
    bl_idname = "uefy.pose_character"
    bl_label = "Posing"
    bl_description = "Pose the Character"
    
    character_name : StringProperty()
    uemann_name : StringProperty()
    
    bones = [
            'clavicle_l', 'upperarm_l', 'lowerarm_l', 'hand_l', 'thumb_01_l', 'thumb_02_l', 'thumb_03_l',
            'index_01_l', 'index_02_l', 'index_03_l', 'middle_01_l', 'middle_02_l', 'middle_03_l',
            'ring_01_l', 'ring_02_l', 'ring_03_l', 'pinky_01_l', 'pinky_02_l', 'pinky_03_l', 'thigh_l','calf_l'
            #, 'foot.L', 'toe.L'
            ]
    
    def update_pose(self, bone_name):
        
        source = bpy.data.objects.get(self.uemann_name)
        target = bpy.data.objects.get(self.character_name)
        
        s_bone = source.pose.bones[bone_name]
        t_bone = target.pose.bones.get(bone_name)
        
        if t_bone is None:
            return
        
        s_bone_world_matrix = source.matrix_world @ s_bone.matrix
        t_bone_world_matrix = target.matrix_world @ t_bone.matrix
        
        reverse = t_bone_world_matrix.inverted() @ s_bone_world_matrix
        
        loc, rot, sca = reverse.decompose()
        t_bone.rotation_quaternion = rot.copy()
        
        bpy.context.view_layer.update() 
        
        return
    
    def execute(self, context):
        
        uemann = bpy.data.objects.get(self.uemann_name)
        character = bpy.data.objects.get(self.character_name)
        
        if uemann is None:
            self.report({'ERROR'}, "UE Mannequin is not set in Uefy Script Panel properties.")
            return {'FINISHED'}
        if character is None:
            self.report({'ERROR'}, "Character is not set in Uefy Script Panel properties")
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        for bone_name in self.bones:
            self.update_pose(bone_name)
        
        bpy.ops.pose.select_all(action='DESELECT')
        
        dbones = character.data.bones
        
        for name in self.bones:
            bone = dbones.get(name)
            if bone is not None:
                bone.select = True
                bone.select_head = True
                bone.select_tail = True
        
        bpy.ops.pose.copy()
        bpy.ops.pose.paste(flipped=True)
        
        bpy.ops.pose.select_all(action='DESELECT')
        
        self.report({'INFO'}, 'Success. Make sure to manually adjust feet bones and floor height.')
        
        return {'FINISHED'}
        
class UEFY_OT_pose_metarig(bpy.types.Operator):
    bl_idname = "uefy.pose_metarig"
    bl_label = "Pose Metarig"
    bl_description = "Pose metarig to match character"
    
    character_name : StringProperty()
    metarig_name : StringProperty()
    
    
    mapping = {
        #"pelvis": "spine",
        #"spine.001": "spine_01",
        #"spine.002": "spine_02",
        #"spine.003": "spine_03",
        "shoulder.L": "clavicle_l",
        "upper_arm.L": "upperarm_l",
        "forearm.L": "lowerarm_l",
        "hand.L": "hand_l",
        "f_index.01.L": "index_01_l",
        "f_index.02.L": "index_02_l",
        "f_index.03.L": "index_03_l",
        "f_middle.01.L": "middle_01_l",
        "f_middle.02.L": "middle_02_l",
        "f_middle.03.L": "middle_03_l",
        "f_pinky.01.L": "pinky_01_l",
        "f_pinky.02.L": "pinky_02_l",
        "f_pinky.03.L": "pinky_03_l",
        "f_ring.01.L": "ring_01_l",
        "f_ring.02.L": "ring_02_l",
        "f_ring.03.L": "ring_03_l",
        "thumb.01.L": "thumb_01_l",
        "thumb.02.L": "thumb_02_l",
        "thumb.03.L": "thumb_03_l",
        "shoulder.R": "clavicle_r",
        "upper_arm.R": "upperarm_r",
        "forearm.R": "lowerarm_r",
        "hand.R": "hand_r",
        "f_index.01.R": "index_01_r",
        "f_index.02.R": "index_02_r",
        "f_index.03.R": "index_03_r",
        "f_middle.01.R": "middle_01_r",
        "f_middle.02.R": "middle_02_r",
        "f_middle.03.R": "middle_03_r",
        "f_pinky.01.R": "pinky_01_r",
        "f_pinky.02.R": "pinky_02_r",
        "f_pinky.03.R": "pinky_03_r",
        "f_ring.01.R": "ring_01_r",
        "f_ring.02.R": "ring_02_r",
        "f_ring.03.R": "ring_03_r",
        "thumb.01.R": "thumb_01_r",
        "thumb.02.R": "thumb_02_r",
        "thumb.03.R": "thumb_03_r",
        #"neck": "neck_01",
        #"head": "head",
        "thigh.L": "thigh_l",
        "shin.L": "calf_l",
        "foot.L": "foot_l",
        "toe.L": "ball_l",
        "thigh.R": "thigh_r",
        "shin.R": "calf_r",
        "foot.R": "foot_r",
        "toe.R": "ball_r"
    }
    
    rolls = {
        'shoulder.L' : 1,
        'upper_arm.L' : 2,
        'forearm.L' : 2,
        'hand.L' : 0,
        'thumb.01.L' : 3,
        'thumb.02.L' : 3,
        'thumb.03.L' : 3,
        'f_index.01.L' : 3,
        'f_index.02.L' : 3,
        'f_index.03.L' : 3,
        'f_middle.01.L' : 3,
        'f_middle.02.L' : 3,
        'f_middle.03.L' : 3,
        'f_ring.01.L' : 3,
        'f_ring.02.L' : 3,
        'f_ring.03.L' : 3,
        'f_pinky.01.L' : 3,
        'f_pinky.02.L' : 3,
        'f_pinky.03.L' : 3,
        'thigh.L' : 3,
        'shin.L' : 3,
        'foot.L' : 0,
        'toe.L' : 3,
        
        'shoulder.R' : 1,
        'upper_arm.R' : 3,
        'forearm.R' : 3,
        'hand.R' : 0,
        'thumb.01.R' : 2,
        'thumb.02.R' : 2,
        'thumb.03.R' : 2,
        'f_index.01.R' : 2,
        'f_index.02.R' : 2,
        'f_index.03.R' : 2,
        'f_middle.01.R' : 2,
        'f_middle.02.R' : 2,
        'f_middle.03.R' : 2,
        'f_ring.01.R' : 2,
        'f_ring.02.R' : 2,
        'f_ring.03.R' : 2,
        'f_pinky.01.R' : 2,
        'f_pinky.02.R' : 2,
        'f_pinky.03.R' : 2,
        'thigh.R' : 2,
        'shin.R' : 2,
        'foot.R' : 0,
        'toe.R' : 2,
    }
    
    
    def move_bone(self, tname, sname):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        character = bpy.data.objects.get(self.character_name)
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        cbone = character.pose.bones.get(sname)
        if cbone is None:
            print("cbone is none: " + sname)
            return
        
        head = cbone.head.copy()
        tail = cbone.tail.copy()
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        mbone = metarig.data.edit_bones.get(tname)
        if mbone is None:
            print("mbone is none:" + tname)
            return
        
        mbone.head = head.copy()
        mbone.tail = tail.copy()
        
        return
    
    def get_axis_vec(self, bone, axis_type):
        
        if axis_type == 0:
            return bone.x_axis
        elif axis_type == 1:
            return bone.x_axis * -1.0
        elif axis_type == 2:
            return bone.z_axis
        elif axis_type == 3:
            return bone.z_axis * -1.0
        
        return
    
    def roll_bone(self, name, index):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        character = bpy.data.objects.get(self.character_name)
        
        mbones = metarig.data.edit_bones
        cbones = character.data.edit_bones
        
        mbone = mbones.get(name)
        
        if mbone is None:
            print("mbone is NONE: " + name)
            return
        
        cname = self.mapping[name]
        cbone = cbones.get(cname)
        if cbone is None:
            print("cbone is NONE: " + name)
            return
        
        vec = self.get_axis_vec(cbone, index)
        UEFY_FUNC_align_x_axis(mbone, vec)
        
        return
    
    def fix_twist(self, name):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        ebones = metarig.data.edit_bones
        
        bone = ebones[name]
        parent = bone.parent
        pname = parent.name
        
        bone.head = parent.head.copy()
        bone.tail = parent.tail.copy()
        bone.roll = parent.roll
        
        bpy.context.view_layer.update() 
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        pbones = metarig.pose.bones
        limb_segments = pbones[pname].rigify_parameters.segments
        limb_segments = 2 if limb_segments <= 1 else limb_segments
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        bone = ebones[name]
        bone.length = bone.length / limb_segments
        
        bpy.context.view_layer.update() 
        
        return
        
    def process_twist(self):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        ebones = metarig.data.edit_bones
        
        twists = []
        
        for bone in ebones:
            if bone.name[:6] == 'twist_':
                twists.append(bone.name)
        
        for twist in twists:
            self.fix_twist(twist)
        
        return
    
    def execute(self, context):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        character = bpy.data.objects.get(self.character_name)
        
        if metarig is None:
            self.report({'ERROR'}, "Metarig is not set in Uefy Script Panel properties.")
            return {'FINISHED'}
        if character is None:
            self.report({'ERROR'}, "Character is not set in Uefy Script Panel properties")
            return {'FINISHED'}
        
        if not isclose(context.scene.unit_settings.scale_length, 0.01, abs_tol=0.001):
            self.report({'ERROR'}, "WARNING: World unit scale is not 0.01")
        
        if metarig.location[0] != 0 or metarig.location[1] != 0 or metarig.location[2] != 0:
            self.report({'ERROR'}, "ERROR: Apply Location (Ctrl + A) on Metarig. Location must be (0,0,0) for this operator")
            return {'FINISHED'}

        if metarig.rotation_euler[0] != 0 or metarig.rotation_euler[1] != 0 or metarig.rotation_euler[2] != 0:
            self.report({'ERROR'}, "ERROR: Apply Rotation (Ctrl + A) on Metarig. Rotation must be (0,0,0) for this operator")
            return {'FINISHED'}

        if metarig.scale[0] != 1 or metarig.scale[1] != 1 or metarig.scale[2] != 1:
            self.report({'ERROR'}, "ERROR: Apply Scale (Ctrl + A) on Metarig. Scale must be (1,1,1) for this operator")
            return {'FINISHED'}
        
        for k, v in self.mapping.items():
            self.move_bone(k, v)
        
        bpy.context.view_layer.update() 
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        character.select_set(True)
        metarig.select_set(True)
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        for k, v in self.rolls.items():
            self.roll_bone(k, v)
            bpy.context.view_layer.update() 
        
        self.process_twist()
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        return {'FINISHED'}
        
class UEFY_OT_fix_metarig(bpy.types.Operator):
    bl_idname = "uefy.fix_metarig"
    bl_label = "Fix Metarig"
    bl_description = "Make metarig compatible for Epic Skeleton"
    
    target_name : StringProperty()
    
    fix_metarig : BoolProperty()
    remove_face : BoolProperty()
    remove_extras_chest : BoolProperty()
    remove_extras_pelvis : BoolProperty()
    add_twist : BoolProperty()
    fix_fingers : BoolProperty()
    rig_mode : StringProperty()
    
    def delete_bone(self, bone_name, edit_bones):
        
        b = edit_bones.get(bone_name)
        if b is not None:
            edit_bones.remove(b)
        return
    
    def do_fix_axis(self):
        
        target = bpy.data.objects.get(self.target_name)
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        pbones = target.pose.bones
        
        pbones['upper_arm.L'].rigify_parameters.rotation_axis = 'x'
        pbones['upper_arm.R'].rigify_parameters.rotation_axis = 'x'
        pbones['thigh.L'].rigify_parameters.rotation_axis = 'x'
        pbones['thigh.R'].rigify_parameters.rotation_axis = 'x'
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        return
    
    def do_remove_face(self, context):
        
        target = bpy.data.objects.get(self.target_name)
        
        context.view_layer.objects.active = target
        
        ebones = target.data.edit_bones
        
        face_bone = ebones.get('face')
        if face_bone is None:
            self.report({'WARNING'}, "Face bone not found")
            return
        
        show_face_layers = [ 
            True, False, False, False, False, False, False, False, 
            False, False, False, False, False, False, False, False, 
            False, False, False, False, False, False, False, False, 
            False, False, False, False, False, False, False, False
        ] 
        
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.armature.armature_layers(layers=show_face_layers)
        bpy.ops.armature.select_all(action='SELECT')

        bpy.context.view_layer.update()
        
        bpy.ops.armature.delete()
        
        bpy.ops.armature.layers_show_all(all=True)
        bpy.ops.armature.select_all(action='DESELECT')
        
        bpy.context.view_layer.update()
        
        return
    
    def do_remove_extras_chest(self):
        
        target = bpy.data.objects.get(self.target_name)
        
        ebones = target.data.edit_bones
        self.delete_bone('breast.L', ebones)
        self.delete_bone('breast.R', ebones)
        
        bpy.context.view_layer.update()
        
        return
    
    def do_remove_extras_pelvis(self):
    
        target = bpy.data.objects.get(self.target_name)
        
        ebones = target.data.edit_bones
        self.delete_bone('pelvis.L', ebones)
        self.delete_bone('pelvis.R', ebones)
        
        bpy.context.view_layer.update()
        
        return
    
    def do_fix_neck(self):
        
        target = bpy.data.objects.get(self.target_name)
        
        ebones = target.data.edit_bones
        
        self.delete_bone('spine.005', ebones)
        
        head = ebones['spine.006']
        neck = ebones['spine.004']
        
        neck.tail = head.head.copy()
        head.use_connect = True
        
        bpy.context.view_layer.update()
        
        return
    
    def do_fix_palm(self):
        
        target = bpy.data.objects.get(self.target_name)
        
        ebones = target.data.edit_bones
        
        self.delete_bone('palm.01.L', ebones)
        self.delete_bone('palm.02.L', ebones)
        self.delete_bone('palm.03.L', ebones)
        self.delete_bone('palm.04.L', ebones)
        self.delete_bone('palm.01.R', ebones)
        self.delete_bone('palm.02.R', ebones)
        self.delete_bone('palm.03.R', ebones)
        self.delete_bone('palm.04.R', ebones)
        
        bpy.context.view_layer.update()
        
        return
    
    def do_fix_metarig(self):
        
        self.do_fix_palm()
        self.do_fix_neck()
        self.do_fix_axis()
        
        return
    
    def resize_half_bone(self, bone_name):
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        target = bpy.data.objects.get(self.target_name)
        
        edit_bones = target.data.edit_bones
        
        bone = edit_bones[bone_name]
        
        direction = bone.vector.copy()
        direction.normalize()
        
        offset = direction * (bone.length / 2.0)
        
        bone.tail = bone.tail - offset
        
        return
    
    def add_twist_bone(self, bone_name, owning_bone_name, layers):
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        target = bpy.data.objects.get(self.target_name)
        
        edit_bones = target.data.edit_bones
        owner = edit_bones.get(owning_bone_name)
        
        if owner is None:
            self.report({'WARNING'}, "Missing twist parent bones. Make sure this operator is run only on the metarig")
            return

        bone = edit_bones.new(bone_name)
        bone.parent = owner
        bone.head = owner.head.copy()
        bone.tail = owner.tail.copy()
        bone.roll = owner.roll
        bone.use_connect = False
        bone.layers = layers
        
        dg = bpy.context.evaluated_depsgraph_get()
        dg.update()
        
        bpy.ops.object.mode_set(mode = 'POSE')
        target.pose.bones[bone_name].rigify_type = "basic.super_copy"
        
        return
    
    def remove_legacy_twist(self):
        
        target = bpy.data.objects.get(self.target_name)
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        
        edit_bones = target.data.edit_bones
        
        lbone = edit_bones.get('cupperarm_twist_01_l')
        if lbone is not None:
            edit_bones.remove(lbone)
        lbone = edit_bones.get('clowerarm_twist_02_l')
        if lbone is not None:
            edit_bones.remove(lbone)
        lbone = edit_bones.get('cupperarm_twist_01_r')
        if lbone is not None:
            edit_bones.remove(lbone)
        lbone = edit_bones.get('clowerarm_twist_02_r')
        if lbone is not None:
            edit_bones.remove(lbone)

        lbone = edit_bones.get('cthigh_twist_01_l')
        if lbone is not None:
            edit_bones.remove(lbone)
        lbone = edit_bones.get('ccalf_twist_02_l')
        if lbone is not None:
            edit_bones.remove(lbone)
        lbone = edit_bones.get('cthigh_twist_01_r')
        if lbone is not None:
            edit_bones.remove(lbone)
        lbone = edit_bones.get('ccalf_twist_02_r')
        if lbone is not None:
            edit_bones.remove(lbone)
        
        return
    
    def do_add_twist(self):
        
        target = bpy.data.objects.get(self.target_name)
                
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        
        edit_bones = target.data.edit_bones
        
        self.add_twist_bone('twist_01.upper_arm.L', 'upper_arm.L', TweakArmLeftLayers)
        self.add_twist_bone('twist_01.upper_arm.R', 'upper_arm.R', TweakArmRightLayers)
        
        self.resize_half_bone('twist_01.upper_arm.L')
        self.resize_half_bone('twist_01.upper_arm.R')
        
        self.add_twist_bone('twist_01.thigh.L', 'thigh.L', TweakLegLeftLayers)
        self.add_twist_bone('twist_01.thigh.R', 'thigh.R', TweakLegRightLayers)
        
        self.resize_half_bone('twist_01.thigh.L')
        self.resize_half_bone('twist_01.thigh.R')
        
        return
    
    def do_fix_fingers(self):
        
        target = bpy.data.objects.get(self.target_name)
                
        bpy.ops.object.mode_set(mode = 'POSE')
        
        pbones = target.pose.bones
        
        for pbone in pbones:
            if pbone.rigify_type == 'limbs.super_finger':
                pbone.rigify_parameters.primary_rotation_axis = 'X'
        
        bpy.context.view_layer.update()
        
        return
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def execute(self, context):
        
        target = bpy.data.objects.get(self.target_name)
        
        if target is None:
            self.report({'ERROR'}, "Metarig is not set in Uefy Script Panel properties.")
            return {'FINISHED'}
        
        if not isclose(context.scene.unit_settings.scale_length, 0.01, abs_tol=0.001):
            self.report({'ERROR'}, "ERROR: World unit scale is not 0.01")
        
        if target.location[0] != 0 or target.location[1] != 0 or target.location[2] != 0:
            self.report({'ERROR'}, "ERROR: Apply Location (Ctrl + A) on Metarig. Location must be (0,0,0) for this operator")
            return {'FINISHED'}

        if target.rotation_euler[0] != 0 or target.rotation_euler[1] != 0 or target.rotation_euler[2] != 0:
            self.report({'ERROR'}, "ERROR: Apply Rotation (Ctrl + A) on Metarig. Rotation must be (0,0,0) for this operator")
            return {'FINISHED'}

        if target.scale[0] != 1 or target.scale[1] != 1 or target.scale[2] != 1:
            self.report({'ERROR'}, "ERROR: Apply Scale (Ctrl + A) on Metarig. Scale must be (1,1,1) for this operator")
            return {'FINISHED'}
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        target.select_set(True)
        
        context.view_layer.objects.active = target
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        if self.fix_metarig == True:
            self.do_fix_metarig()
        
        if self.remove_extras_chest == True:
            self.do_remove_extras_chest()
        
        if self.remove_extras_pelvis == True:
            self.do_remove_extras_pelvis()

        if self.remove_face == True:
            self.do_remove_face(context)
        
        if self.add_twist == True:
            self.remove_legacy_twist()
            self.do_add_twist()
        
        if self.fix_fingers == True:
            self.do_fix_fingers()
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        return {'FINISHED'}
        
UEBoneAlignMapping = {
    "pelvis" : ('z', -1.0, 1.0),
    "spine_01" : ('z', -1.0, 1.0),
    "spine_02" : ('z', -1.0, 1.0),
    "spine_03" : ('z', -1.0, 1.0),
    "clavicle_l" : ('x', -1.0, 1.0),
    "upperarm_l" : ('z', -1.0, 1.0),
    "lowerarm_l" : ('z', -1.0, 1.0),
    "hand_l" : ('x', 1.0, 1.0),
    "index_01_l" : ('z', 1.0, 1.0),
    "index_02_l" : ('z', 1.0, 1.0),
    "index_03_l" : ('z', 1.0, 1.0),
    "middle_01_l" : ('z', 1.0, 1.0),
    "middle_02_l" : ('z', 1.0, 1.0),
    "middle_03_l" : ('z', 1.0, 1.0),
    "pinky_01_l" : ('z', 1.0, 1.0),
    "pinky_02_l" : ('z', 1.0, 1.0),
    "pinky_03_l" : ('z', 1.0, 1.0),
    "ring_01_l" : ('z', 1.0, 1.0),
    "ring_02_l" : ('z', 1.0, 1.0),
    "ring_03_l" : ('z', 1.0, 1.0),
    "thumb_01_l" : ('z', 1.0, 1.0),
    "thumb_02_l" : ('z', 1.0, 1.0),
    "thumb_03_l" : ('z', 1.0, 1.0),
    "clavicle_r" : ('x', -1.0, -1.0),
    "upperarm_r" : ('z', 1.0, -1.0),
    "lowerarm_r" : ('z', 1.0, -1.0),
    "hand_r" : ('x', 1.0, -1.0),
    "index_01_r" : ('z', -1.0, -1.0),
    "index_02_r" : ('z', -1.0, -1.0),
    "index_03_r" : ('z', -1.0, -1.0),
    "middle_01_r" : ('z', -1.0, -1.0),
    "middle_02_r" : ('z', -1.0, -1.0),
    "middle_03_r" : ('z', -1.0, -1.0),
    "pinky_01_r" : ('z', -1.0, -1.0),
    "pinky_02_r" : ('z', -1.0, -1.0),
    "pinky_03_r" : ('z', -1.0, -1.0),
    "ring_01_r" : ('z', -1.0, -1.0),
    "ring_02_r" : ('z', -1.0, -1.0),
    "ring_03_r" : ('z', -1.0, -1.0),
    "thumb_01_r" : ('z', -1.0, -1.0),
    "thumb_02_r" : ('z', -1.0, -1.0),
    "thumb_03_r" : ('z', -1.0, -1.0),
    "neck_01" : ('z', -1.0, 1.0),
    "head" : ('z', -1.0, 1.0),
    "thigh_l" : ('z', 1.0, -1.0),
    "calf_l" : ('z', 1.0, -1.0),
    #"foot_l" : ('z', 1.0, -1.0),
    "ball_l" : ('z', 1.0, 1.0),
    "thigh_r" : ('z', -1.0, 1.0),
    "calf_r" : ('z', -1.0, 1.0),
    #"foot_r" : ('z', -1.0, 1.0),
    "ball_r" : ('z', -1.0, -1.0),
    "upperarm_twist_01_l" : ('z', -1.0, 1.0),
    "upperarm_twist_02_l" : ('z', -1.0, 1.0),
    "lowerarm_twist_01_l" : ('z', -1.0, 1.0),
    "lowerarm_twist_02_l" : ('z', -1.0, 1.0),
    "thigh_twist_01_l" : ('z', 1.0, -1.0),
    "thigh_twist_02_l" : ('z', 1.0, -1.0),
    "calf_twist_01_l" : ('z', 1.0, -1.0),
    "calf_twist_02_l" : ('z', 1.0, -1.0),
    "upperarm_twist_01_r" : ('z', 1.0, -1.0),
    "upperarm_twist_02_r" : ('z', 1.0, -1.0),
    "lowerarm_twist_01_r" : ('z', 1.0, -1.0),
    "lowerarm_twist_02_r" : ('z', 1.0, -1.0),
    "thigh_twist_01_r" : ('z', -1.0, 1.0),
    "thigh_twist_02_r" : ('z', -1.0, 1.0),
    "calf_twist_01_r" : ('z', -1.0, 1.0),
    "calf_twist_02_r" : ('z', -1.0, 1.0)
}

class UEFY_OT_ue_export_align(bpy.types.Operator):
    bl_idname = "uefy.ue_export_align"
    bl_label = "UE Mannequin Rolls"
    bl_description = "(Experimental) Set export bones to Original UE4 Mannequin bone rolls. Only use on Generated Rig with built Unreal Skeleton. Destructive operation not compatible with rigify."
    
    move_thigh_twist : bpy.props.BoolProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def setup_skeleton(self, context):
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        bones = context.object.data.edit_bones
        pbone_names = []
        
        for bone in bones:
            if bone.layers[24] or bone.layers[25] or bone.layers[26]:
                bone.use_connect = False
                pbone_names.append(bone.name)
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        for pbone_name in pbone_names:
            pbone = context.object.pose.bones[pbone_name]
            for c in pbone.constraints:
                c.influence = 0.0
        
        return

    def fix_foot(self, context):
        
        edit_bones = context.object.data.edit_bones
        
        foot_l = edit_bones['foot_l']
        foot_r = edit_bones['foot_r']
        
        y = mathutils.Vector([0,1,0])
        
        self.process_bone(foot_l, y, 1.0, -1.0)
        self.process_bone(foot_r, y, -1.0, 1.0)
        
        return
    
    def copy_bone(self, source, target):
        
        target.head = source.head
        target.tail = source.tail
        target.roll = source.roll
        
        return
    
    def fix_ik(self, context):
        
        edit_bones = context.object.data.edit_bones
        
        ik_hand_l = edit_bones.get('ik_hand_l')
        ik_hand_r = edit_bones.get('ik_hand_r')
        ik_hand_gun = edit_bones.get('ik_hand_gun')
        #ik_hand_root = edit_bones.get('ik_hand_root')
        
        #ik_foot_root = edit_bones.get('ik_foot_root')
        ik_foot_l = edit_bones.get('ik_foot_l')
        ik_foot_r = edit_bones.get('ik_foot_r')
        
        hand_l = edit_bones.get('hand_l')
        hand_r = edit_bones.get('hand_r')
        foot_l = edit_bones.get('foot_l')
        foot_r = edit_bones.get('foot_r')
        
        if hand_l is not None and ik_hand_l is not None:
            self.copy_bone(hand_l, ik_hand_l)
        if hand_r is not None and ik_hand_r is not None:
            self.copy_bone(hand_r, ik_hand_r)
        if hand_r is not None and ik_hand_gun is not None:
            self.copy_bone(hand_r, ik_hand_gun)
        if foot_l is not None and ik_foot_l is not None:
            self.copy_bone(foot_l, ik_foot_l)
        if foot_r is not None and ik_foot_r is not None:
            self.copy_bone(foot_r, ik_foot_r)
        
        return

    def get_axis(self, bone, input):
        
        if input == 'x':
            return bone.x_axis
        if input == 'y':
            return bone.y_axis
        if input == 'z':
            return bone.z_axis
        
        return bone.z_axis.copy()
    
    def process_bone(self, bone, axis, align, roll_align):
        
        head = bone.head.copy()
        tail = head + axis * bone.length * align
        
        vec = bone.y_axis.copy()
        vec.normalize()
        
        vec = vec * roll_align
        
        bone.tail = tail
        UEFY_FUNC_align_x_axis(bone, vec)
        
        return
            
    def update_rolls(self, context):
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        edit_bones = context.object.data.edit_bones
        
        for bone_name, bone_data in UEBoneAlignMapping.items():
            bone = edit_bones.get(bone_name)
            if bone is not None:
                av, align, roll_align = bone_data
                axis = self.get_axis(bone, av)
                axis.normalize()
                self.process_bone(bone, axis, align, roll_align)
        
        self.fix_foot(context)
        self.fix_ik(context)
                
        return

    def update_thigh_twist(self, context):
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        edit_bones = context.object.data.edit_bones
        
        thigh_twist_l = edit_bones.get('thigh_twist_01_l')
        thigh_twist_r = edit_bones.get('thigh_twist_01_r')
        
        calf_l = edit_bones.get('calf_l')
        calf_r = edit_bones.get('calf_r')
        
        thigh_l = edit_bones.get('thigh_l')
        thigh_r = edit_bones.get('thigh_r')
        
        if thigh_twist_l is None or thigh_twist_r is None or calf_l is None or calf_r is None or thigh_l is None or thigh_r is None:
            return
        
        a = thigh_l.head.copy()
        b = calf_l.head.copy()
        
        v = b - a
        v = v / 2
        
        thigh_twist_l.head += v
        thigh_twist_l.tail += v
        
        a = thigh_r.head.copy()
        b = calf_r.head.copy()
        
        v = b - a
        v = v / 2
        
        thigh_twist_r.head += v
        thigh_twist_r.tail += v
        
        dg = bpy.context.evaluated_depsgraph_get()
        dg.update()
        
        return

    def execute(self, context):
        
        self.report({'INFO'}, 'Setting UE4 Original Bone Rolls.')
        
        self.setup_skeleton(context)
        self.update_rolls(context)
        
        if self.move_thigh_twist:
            self.update_thigh_twist(context)
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        return {'FINISHED'}
        
class UEFY_OT_roll_bone(bpy.types.Operator):
    bl_idname = "uefy.roll_bone"
    bl_label = "Roll Bone"
    bl_description = "Align selected bone X-axis to chosen axis"
    
    axis_type : bpy.props.IntProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature and context.mode == 'EDIT_ARMATURE'

    def get_axis(self, bone):
        
        if self.axis_type == 0:
            return bone.x_axis
        elif self.axis_type == 1:
            return bone.x_axis * -1.0
        elif self.axis_type == 2:
            return bone.z_axis
        elif self.axis_type == 3:
            return bone.z_axis * -1.0
        
        return bone.x_axis
        
    def update_bone(self, context, bone):
        
        vec = self.get_axis(bone)
        UEFY_FUNC_align_x_axis(bone, vec)
        
        return

    def execute(self, context):
        
        for bone in context.selected_editable_bones:
            self.update_bone(context, bone)
        
        return {'FINISHED'}

class UEFY_OT_swap_y_axis(bpy.types.Operator):
    bl_idname = "uefy.swap_y_axis"
    bl_label = "Swap Y-axis"
    bl_description = "Swap Y-axis with chosen axis"
    
    axis_type : bpy.props.IntProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature and context.mode == 'EDIT_ARMATURE'

    def get_axis(self, bone):
        
        if self.axis_type == 0:
            return bone.x_axis
        elif self.axis_type == 1:
            return bone.x_axis * -1.0
        elif self.axis_type == 2:
            return bone.z_axis
        elif self.axis_type == 3:
            return bone.z_axis * -1.0
        
        return bone.x_axis
        
    def update_bone(self, context, bone):
        
        axis = self.get_axis(bone)
        an = axis.normalized()

        head = bone.head.copy()
        tail = head + an * bone.length
        
        vec = bone.y_axis.copy()
        vec.normalize()
        
        bone.tail = tail
        UEFY_FUNC_align_x_axis(bone, vec)
        
        return

    def execute(self, context):
        
        for bone in context.selected_editable_bones:
            self.update_bone(context, bone)
        
        return {'FINISHED'}
        
        
classes = ( UEFY_OT_pose_character, UEFY_OT_scan_character, UEFY_OT_pose_metarig,
            UEFY_OT_fix_metarig, UEFY_OT_rename_bones, UEFY_OT_auto_roll_bones, UEFY_OT_ue_export_align,
            UEFY_OT_roll_bone, UEFY_OT_swap_y_axis)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    
def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
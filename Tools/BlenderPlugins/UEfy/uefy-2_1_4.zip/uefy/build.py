"""
Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq
https://www.rakiz.com

Created by Rakiz Farooq

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

"""
Uefy 2 is an addon for Blender that provides tools to make Rigify rigs 
suitable for use in game engines.

This addon is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support 
this project and help ensure continued development.
"""
import bpy
import json

from bpy.props import StringProperty
from bpy.props import IntProperty

VertexGroupLookup = {
    "u_spine" : "pelvis",
    "u_spine.001" : "spine_01",
    "u_spine.002" : "spine_02",
    "u_spine.003" : "spine_03",
    "u_shoulder.L" : "clavicle_l",
    "u_upper_arm.L" : "upperarm_l",
    "u_forearm.L" : "lowerarm_l",
    "u_hand.L" : "hand_l",
    "u_f_index.01.L" : "index_01_l",
    "u_f_index.02.L" : "index_02_l",
    "u_f_index.03.L" : "index_03_l",
    "u_f_middle.01.L" : "middle_01_l",
    "u_f_middle.02.L" : "middle_02_l",
    "u_f_middle.03.L" : "middle_03_l",
    "u_f_pinky.01.L" : "pinky_01_l",
    "u_f_pinky.02.L" : "pinky_02_l",
    "u_f_pinky.03.L" : "pinky_03_l",
    "u_f_ring.01.L" : "ring_01_l",
    "u_f_ring.02.L" : "ring_02_l",
    "u_f_ring.03.L" : "ring_03_l",
    "u_thumb.01.L" : "thumb_01_l",
    "u_thumb.02.L" : "thumb_02_l",
    "u_thumb.03.L" : "thumb_03_l",
    "u_shoulder.R" : "clavicle_r",
    "u_upper_arm.R" : "upperarm_r",
    "u_forearm.R" : "lowerarm_r",
    "u_hand.R" : "hand_r",
    "u_f_index.01.R" : "index_01_r",
    "u_f_index.02.R" : "index_02_r",
    "u_f_index.03.R" : "index_03_r",
    "u_f_middle.01.R" : "middle_01_r",
    "u_f_middle.02.R" : "middle_02_r",
    "u_f_middle.03.R" : "middle_03_r",
    "u_f_pinky.01.R" : "pinky_01_r",
    "u_f_pinky.02.R" : "pinky_02_r",
    "u_f_pinky.03.R" : "pinky_03_r",
    "u_f_ring.01.R" : "ring_01_r",
    "u_f_ring.02.R" : "ring_02_r",
    "u_f_ring.03.R" : "ring_03_r",
    "u_thumb.01.R" : "thumb_01_r",
    "u_thumb.02.R" : "thumb_02_r",
    "u_thumb.03.R" : "thumb_03_r",
    "u_spine.004" : "neck_01",
    "u_spine.006" : "head",
    "u_thigh.L" : "thigh_l",
    "u_shin.L" : "calf_l",
    "u_foot.L" : "foot_l",
    "u_toe.L" : "ball_l",
    "u_thigh.R" : "thigh_r",
    "u_shin.R" : "calf_r",
    "u_foot.R" : "foot_r",
    "u_toe.R" : "ball_r",
    "u_twist_01.upper_arm.L" : "upperarm_twist_01_l",
    "u_upper_arm.L.001" : "upperarm_twist_02_l",
    "u_twist_01.forearm.L" : "lowerarm_twist_01_l",
    "u_twist_02.forearm.L" : "lowerarm_twist_02_l",
    "u_twist_01.thigh.L" : "thigh_twist_01_l",
    "u_twist_02.thigh.L" : "thigh_twist_02_l",
    "u_twist_01.shin.L" : "calf_twist_01_l",
    "u_twist_02.shin.L" : "calf_twist_02_l",
    
    "u_twist_01.upper_arm.R" : "upperarm_twist_01_r",
    "u_upper_arm.R.001" : "upperarm_twist_02_r",
    "u_twist_01.forearm.R" : "lowerarm_twist_01_r",
    "u_twist_02.forearm.R" : "lowerarm_twist_02_r",
    "u_twist_01.thigh.R" : "thigh_twist_01_r",
    "u_twist_02.thigh.R" : "thigh_twist_02_r",
    "u_twist_01.shin.R" : "calf_twist_01_r",
    "u_twist_02.shin.R" : "calf_twist_02_r"
}

class UEFY_OT_build_skeleton(bpy.types.Operator):
    bl_idname = "uefy.build_skeleton"
    bl_label = "Build Skeleton"
    bl_description = "Build Skeleton Suitable for Game Engine"
    
    metarig_name : StringProperty()
    rig_name : StringProperty()
    rig_mode : IntProperty()
    twist_mode : IntProperty()
    
    BoneMap = {}
    
    DeformLayers = [ 
        False, False, False, False, False, False, False, False, 
        False, False, False, False, False, False, False, False, 
        False, False, False, False, False, False, False, False, 
        True, False, False, False, False, False, False, False
    ]
    
    FaceLayers = [ 
        False, False, False, False, False, False, False, False, 
        False, False, False, False, False, False, False, False, 
        False, False, False, False, False, False, False, False, 
        False, True, False, False, False, False, False, False
    ]
    
    IKLayers = [ 
        False, False, False, False, False, False, False, False, 
        False, False, False, False, False, False, False, False, 
        False, False, False, False, False, False, False, False, 
        False, False, True, False, False, False, False, False
    ]
    
    def process_bone(self, source, parent, local=False):
        
        rig = bpy.data.objects.get(self.rig_name)
        
        ebones = rig.data.edit_bones
        pbones = rig.pose.bones
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        def_name = "DEF-" + source
        target = ebones.get(def_name)

        name = "u_" + source
        if parent != "root":
            parent = "u_" + parent
        
        bone = ebones.new(name)
        
        bone.parent = ebones.get(parent)
        bone.use_connect = target.use_connect
        bone.matrix = target.matrix.copy()
        bone.head = target.head.copy()
        bone.tail = target.tail.copy()
        bone.roll = target.roll
        bone.layers = self.DeformLayers
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        pbone = pbones.get(name)
        c = pbone.constraints.new(type='COPY_TRANSFORMS')
        c.target = rig
        c.subtarget = def_name
        if local:
            c.target_space = 'LOCAL'
            c.owner_space = 'LOCAL'
        
        return
    
    def process_chain(self, source):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        rig = bpy.data.objects.get(self.rig_name)
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        ebones = rig.data.bones
        
        for record in self.BoneMap[source]:
            for bone, parent in record.items():
                if bone[:5] == "heel." or bone[:6] == "twist_":
                    continue
                self.process_bone(bone, parent)
            
        return
    
    def process_basic_spine(self, source):
        self.process_chain(source)
        return
    
    def process_super_copy(self, source):
        self.process_chain(source)
        
    def get_segment_name(self, name, num):
        
        if num <= 1:
            segment_name = "DEF-" + name
        else:
            num = num - 1
            segment_name = "DEF-" + name + "." + f"{num:03d}"
        
        return segment_name
        
    def process_segment(self, source, parent):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        rig = bpy.data.objects.get(self.rig_name)
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        ebones = rig.data.edit_bones
        
        name = "u_" + source[4:]
        target = ebones.get(source)
        
        bone = ebones.new(name)
        
        if bone.name != name:
            self.report({'WARNING'}, "Bone with name '"+ name +"' already exists.")
        
        bone.parent = ebones.get(parent)
        bone.use_connect = target.use_connect
        bone.matrix = target.matrix.copy()
        bone.head = target.head.copy()
        bone.tail = target.tail.copy()
        bone.roll = target.roll
        bone.layers = self.DeformLayers
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        pbones = rig.pose.bones
        
        pbone = pbones.get(name)
        c = pbone.constraints.new(type='COPY_TRANSFORMS')
        c.target = rig
        c.subtarget = source
        
        return name
    
    def process_limb_leg(self, source):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        bpy.ops.object.mode_set(mode='POSE')
        
        pbones = metarig.pose.bones
        limb_segments = pbones[source].rigify_parameters.segments
        
        parts = []
        
        for record in self.BoneMap[source]:
            for k, v in record.items():
                parts.append((k,v))
        
        thigh = 0
        shin = 1
        foot = 2
        toe = 3
        
        k, v = parts[thigh]
        parent = "u_" + v
        
        # thigh
        i = 1
        while i <= limb_segments:
            k, v = parts[thigh]
            sname = self.get_segment_name(k, i)
            parent = self.process_segment(sname, parent)
            i = i + 1
        
        # shin
        i = 1
        while i <= limb_segments:
            k, v = parts[shin]
            sname = self.get_segment_name(k, i)
            parent = self.process_segment(sname, parent)
            i = i + 1
        
        # foot
        i = 1
        k, v = parts[foot]
        sname = self.get_segment_name(k, i)
        parent = self.process_segment(sname, parent)
        
        # toe
        i = 1
        k, v = parts[toe]
        sname = self.get_segment_name(k, i)
        parent = self.process_segment(sname, parent)
        
        
        return
    
    def process_limb_paw(self, source):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        bpy.ops.object.mode_set(mode='POSE')
        
        pbones = metarig.pose.bones
        limb_segments = pbones[source].rigify_parameters.segments
        
        parts = []
        
        for record in self.BoneMap[source]:
            for k, v in record.items():
                parts.append((k,v))
        
        thigh = 0
        shin = 1
        foot = 2
        toe = 3
        
        k, v = parts[thigh]
        parent = "u_" + v
        
        # thigh
        i = 1
        while i <= limb_segments:
            k, v = parts[thigh]
            sname = self.get_segment_name(k, i)
            parent = self.process_segment(sname, parent)
            i = i + 1
        
        # shin
        i = 1
        while i <= limb_segments:
            k, v = parts[shin]
            sname = self.get_segment_name(k, i)
            parent = self.process_segment(sname, parent)
            i = i + 1
        
        # foot
        i = 1
        k, v = parts[foot]
        sname = self.get_segment_name(k, i)
        parent = self.process_segment(sname, parent)
        
        # toe
        i = 1
        k, v = parts[toe]
        sname = self.get_segment_name(k, i)
        parent = self.process_segment(sname, parent)
        
        
        return
    
    def process_limb_arm(self, source):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        bpy.ops.object.mode_set(mode='POSE')
        
        pbones = metarig.pose.bones
        limb_segments = pbones[source].rigify_parameters.segments
        
        parts = []
        
        for record in self.BoneMap[source]:
            for k, v in record.items():
                parts.append((k,v))
        
        upperarm = 0
        lowerarm = 1
        hand = 2
        
        k, v = parts[upperarm]
        parent = "u_" + v
        
        # upperarm
        i = 1
        while i <= limb_segments:
            k, v = parts[upperarm]
            sname = self.get_segment_name(k, i)
            parent = self.process_segment(sname, parent)
            i = i + 1
        
        # lowerarm
        i = 1
        while i <= limb_segments:
            k, v = parts[lowerarm]
            sname = self.get_segment_name(k, i)
            parent = self.process_segment(sname, parent)
            i = i + 1
        
        # hand
        i = 1
        k, v = parts[hand]
        sname = self.get_segment_name(k, i)
        parent = self.process_segment(sname, parent)
        
        
        return
    
    def get_twist_name(self, name, num, limb_segments, is_upper):
        
        if is_upper:
            num = f"{num:02d}"
            twist_name = "u_twist_" + str(num) + "." + name
        else:
            num = limb_segments - num + 1
            num = f"{num:02d}"
            twist_name = "u_twist_" + str(num) + "." + name
        
        return twist_name
    
    def duplicate_twist(self, source, parent, tname, constrain):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        rig = bpy.data.objects.get(self.rig_name)
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        ebones = rig.data.edit_bones
        
        name = tname
        target = ebones.get(source)
        
        bone = ebones.new(name)
        
        if name != bone.name:
            self.report({'ERROR'}, 'This operation might have already been run on this rig. Check if you want to proceed or undo this step.')
        
        bone.parent = ebones.get(parent)
        bone.use_connect = False
        bone.matrix = target.matrix.copy()
        bone.head = target.head.copy()
        bone.tail = target.tail.copy()
        bone.roll = target.roll
        bone.layers = self.DeformLayers
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        pbones = rig.pose.bones
        
        if constrain == True:
            pbone = pbones.get(name)
            c = pbone.constraints.new(type='COPY_TRANSFORMS')
            c.target = rig
            c.subtarget = source
        else:
            pbone = pbones.get(name)
            c = pbone.constraints.new(type='COPY_TRANSFORMS')
            c.target = rig
            c.subtarget = tname[2:]
            c.target_space = 'LOCAL'
            c.owner_space = 'LOCAL'
        
        return name
    
    def process_twist(self, source):
        metarig = bpy.data.objects.get(self.metarig_name)
        
        t_mode = self.twist_mode
        
        # TODO: Exception added in process_chain ... move to it's own function
        
        bpy.ops.object.mode_set(mode='POSE')
        
        twist = source[:8]
        source = source[9:]
        
        pbones = metarig.pose.bones
        limb_segments = pbones[source].rigify_parameters.segments
        
        parts = []
        
        for record in self.BoneMap[source]:
            for k, v in record.items():
                parts.append((k,v))
        
        upperarm = 0
        lowerarm = 1
        hand = 2
        
        k, v = parts[upperarm]
        parent = "u_" + k
        
        # upperarm
        
        if t_mode != 0:
            i = 1
            while i <= limb_segments:
                k, v = parts[upperarm]
                sname = self.get_segment_name(k, i)
                tname = self.get_twist_name(k, i, limb_segments, True)
                if i == 1:
                    constrain = False
                else:
                    constrain = True
                self.duplicate_twist(sname, parent, tname, constrain)
                i = i + 1
                if t_mode == 1 and i > 1:
                    break
        
        k, v = parts[lowerarm]
        parent = "u_" + k
        
        # lowerarm
        
        if t_mode != 0:
            i = 1
            if t_mode == 2:
                while i <= limb_segments:
                    k, v = parts[lowerarm]
                    sname = self.get_segment_name(k, i)
                    tname = self.get_twist_name(k, i, limb_segments, False)
                    self.duplicate_twist(sname, parent, tname, True)
                    i = i + 1
            elif t_mode == 1:
                while i <= limb_segments:
                    if i < limb_segments:
                        i = i + 1
                        continue
                    k, v = parts[lowerarm]
                    sname = self.get_segment_name(k, i)
                    tname = self.get_twist_name(k, i, limb_segments, False)
                    self.duplicate_twist(sname, parent, tname, True)
                    i = i + 1
        return
        
    def process_limb_ue_arm(self, source):
        self.process_chain(source)
        return
    
    def process_limb_ue_leg(self, source):
        self.process_chain(source)
        return
    
    def process_limb_ue_paw(self, source):
        self.process_chain(source)
        return
    
    def process_super_limb(self, source):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        mode = self.rig_mode
        bpy.ops.object.mode_set(mode='POSE')
        
        pbones = metarig.pose.bones
        limb_type = pbones[source].rigify_parameters.limb_type
        
        if mode == 1:
            if limb_type == 'arm':
                self.process_limb_arm(source)
            elif limb_type == 'leg':
                self.process_limb_leg(source)
            elif limb_type == 'paw':
                self.process_limb_paw(source)
        
        if mode == 0:
            if limb_type == 'arm':
                self.process_limb_ue_arm(source)
            elif limb_type == 'leg':
                self.process_limb_ue_leg(source)
            elif limb_type == 'paw':
                self.process_limb_paw(source)
        
        return
    
    def process_super_head(self, source):
        self.process_chain(source)
        return
    
    def duplicate_face_bone(self, name, bone_name, parent_name):
        
        rig = bpy.data.objects.get(self.rig_name)
        ebones = rig.data.edit_bones
        
        ehead_bone = ebones[parent_name]
        target = ebones[bone_name]
        
        bone = ebones.new(name)
        
        bone.parent = ehead_bone
        bone.use_connect = target.use_connect
        bone.matrix = target.matrix.copy()
        bone.head = target.head.copy()
        bone.tail = target.tail.copy()
        bone.roll = target.roll
        bone.layers = self.FaceLayers
        
        return
    
    def process_face_bones(self, bone_name, parent_name):
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        rig = bpy.data.objects.get(self.rig_name)
        ebones = rig.data.edit_bones
        
        bone = ebones[bone_name]
        
        children = list()
        
        for child in bone.children:
            if (child.name.find('DEF-') == 0):
                bone_name = "fc_" + child.name[4:]
                self.duplicate_face_bone(bone_name, child.name, parent_name)
            self.process_face_bones(child.name, parent_name)
        
        return
    
    def process_face_extra(self, face_name):
        
        rig = bpy.data.objects.get(self.rig_name)
        
        ebones = rig.data.edit_bones
        
        bone = ebones.get('MCH-eye.L')
        if bone is not None:
            self.duplicate_face_bone('fc_eye_L', 'MCH-eye.L', face_name)
        bone = ebones.get('MCH-eye.R')
        if bone is not None:
            self.duplicate_face_bone('fc_eye_R', 'MCH-eye.R', face_name)
        bone = ebones.get('teeth.T')
        if bone is not None:
            self.duplicate_face_bone('fc_jaw_T', 'teeth.T', face_name)
        bone = ebones.get('teeth.B')
        if bone is not None:
            self.duplicate_face_bone('fc_jaw_B', 'teeth.B', face_name)
        
        return
    
    def process_super_face(self, source):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        rig = bpy.data.objects.get(self.rig_name)
        
        parts = []
        
        for record in self.BoneMap[source]:
            for k, v in record.items():
                parts.append((k,v))
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        ebones = rig.data.edit_bones
        
        k,v = parts[0]
        org_face_name = "ORG-" + k
        head_bone_name = "u_" + v
        target = ebones[org_face_name]
        ehead_bone = ebones[head_bone_name]
        
        name = "fc_" + org_face_name[4:]
        
        bone = ebones.new(name)
        
        bone.parent = ehead_bone
        bone.use_connect = target.use_connect
        bone.matrix = target.matrix.copy()
        bone.head = target.head.copy()
        bone.tail = target.tail.copy()
        bone.roll = target.roll
        bone.layers = self.FaceLayers
        
        self.process_face_bones(org_face_name, name)
        self.process_face_extra(name)
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        pbones = rig.pose.bones
        pface_bone = pbones[name]
        
        for pbone in pface_bone.children:
            c = pbone.constraints.new(type='COPY_TRANSFORMS')
            c.target = rig
            if pbone.name == 'fc_eye_L':
                c.subtarget = 'MCH-eye.L'
            elif pbone.name == 'fc_eye_R':
                c.subtarget = 'MCH-eye.R'
            elif pbone.name == 'fc_jaw_T':
                c.subtarget = 'teeth.T'
            elif pbone.name == 'fc_jaw_B':
                c.subtarget = 'teeth.B'
            else:
                c.subtarget = 'DEF-' + pbone.name[3:]
        
        return
    
    def process_super_palm(self, source):
        self.process_chain(source)
        return
    
    def process_super_finger(self, source):
        self.process_chain(source)
        return
        
    def process_simple_tentacle(self, source):
        self.process_chain(source)
        return
        
    def process_basic_tail(self, source):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        rig = bpy.data.objects.get(self.rig_name)
        
        pbones = metarig.pose.bones
        connect = pbones[source].rigify_parameters.connect_chain
        
        if not connect:
            self.process_chain(source)
            return
        
        parts = []
        
        for record in self.BoneMap[source]:
            for bone, parent in record.items():
                parts.append((bone, parent))
        
        k, parent = parts[0]
        parts.reverse()
        
        for k, v in parts:
            self.process_bone(k, parent)
            parent = k
        
        return
    
    def is_twist_bone(self, name):
        check = name[:6]
        
        if check == "twist_":
            return True
        
        return False
    
    def process_type(self, source):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        bpy.ops.object.mode_set(mode='POSE')
        
        pbones = metarig.pose.bones
        type = pbones[source].rigify_type
        
        mode = self.rig_mode
        
        if type == 'spines.basic_spine':
            self.process_basic_spine(source)
        elif type == 'limbs.super_limb':
            self.process_super_limb(source)
        elif type == 'basic.super_copy':
            twist = self.is_twist_bone(source)
            if twist:
                if mode == 0:
                    self.process_twist(source)
            else:
                self.process_super_copy(source)
        elif type == 'spines.super_head':
            self.process_super_head(source)
        elif type == 'faces.super_face':
            self.process_super_face(source)
        elif type == 'limbs.super_palm':
            self.process_super_palm(source)
        elif type == 'limbs.super_finger':
            self.process_super_finger(source)
        elif type == 'limbs.simple_tentacle':
            self.process_simple_tentacle(source)
        elif type == 'spines.basic_tail':
            self.process_basic_tail(source)
        
        return
    
    def disable_deforms(self):
        rig = bpy.data.objects.get(self.rig_name)
        bpy.ops.object.mode_set(mode='EDIT')
        
        ebones = rig.data.edit_bones
        
        for bone in ebones:
            if bone.name[:4] == "DEF-":
                bone.use_deform = False
        
        return
    
    def rename_head(self):
        
        rig = bpy.data.objects.get(self.rig_name)
        
        ebones = rig.data.edit_bones
        
        head_ctl = ebones.get('head')
        if head_ctl is None:
            return
        
        head_ctl.name = "head_01"
        
        return
    
    def do_add_ik(self):
        
        rig = bpy.data.objects.get(self.rig_name)
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        
        pose_bones = rig.pose.bones
        edit_bones = rig.data.edit_bones
        
        print("Adding IK bones")
        
        root = edit_bones.get('root')
        
        ik_foot_root = edit_bones.new('ik_foot_root')
        ik_foot_root.parent = root
        ik_foot_root.head = root.head.copy()
        ik_foot_root.tail = root.tail.copy()
        ik_foot_root.use_connect = root.use_connect
        ik_foot_root.matrix = root.matrix.copy()
        ik_foot_root.layers = self.IKLayers
        ik_foot_root.use_deform = True
        
        foot_l = edit_bones.get('u_foot.L')
        foot_r = edit_bones.get('u_foot.R')
        
        hand_r = edit_bones.get('u_hand.R')
        hand_l = edit_bones.get('u_hand.L')
        
        if foot_l is None or foot_r is None or hand_r is None or hand_l is None:
            self.report({'WARNING'}, "IK FAILED: A bone required for IK setup was missing.")
            return
        
        foot_l_name = foot_l.name
        foot_r_name = foot_r.name
        hand_l_name = hand_l.name
        hand_r_name = hand_r.name
        
        ik_foot_l = edit_bones.new('ik_foot_l')
        ik_foot_l.parent = ik_foot_root
        ik_foot_l.head = foot_l.head.copy()
        ik_foot_l.tail = foot_l.tail.copy()
        #ik_foot_l.use_connect = False
        ik_foot_l.layers = self.IKLayers
        ik_foot_l.use_deform = True
        
        ik_foot_r = edit_bones.new('ik_foot_r')
        ik_foot_r.parent = ik_foot_root
        ik_foot_r.head = foot_r.head.copy()
        ik_foot_r.tail = foot_r.tail.copy()
        #ik_foot_r.use_connect = foot_r.use_connect
        ik_foot_r.layers = self.IKLayers
        ik_foot_r.use_deform = True
        
        ik_hand_root = edit_bones.new('ik_hand_root')
        ik_hand_root.parent = root
        ik_hand_root.head = root.head.copy()
        ik_hand_root.tail = root.tail.copy()
        #ik_hand_root.use_connect = root.use_connect
        ik_hand_root.layers = self.IKLayers
        ik_hand_root.use_deform = True
        
        ik_hand_gun = edit_bones.new('ik_hand_gun')
        ik_hand_gun.parent = ik_hand_root
        ik_hand_gun.head = hand_r.head.copy()
        ik_hand_gun.tail = hand_r.tail.copy()
        #ik_hand_gun.tail = hand_l.head.copy()
        #ik_hand_gun.use_connect = hand_r.use_connect
        ik_hand_gun.layers = self.IKLayers
        ik_hand_gun.use_deform = True
        
        ik_hand_l = edit_bones.new('ik_hand_l')
        ik_hand_l.parent = ik_hand_gun
        ik_hand_l.head = hand_l.head.copy()
        ik_hand_l.tail = hand_l.tail.copy()
        #ik_hand_l.use_connect = True
        ik_hand_l.layers = self.IKLayers
        ik_hand_l.use_deform = True
        
        ik_hand_r = edit_bones.new('ik_hand_r')
        ik_hand_r.parent = ik_hand_gun
        ik_hand_r.head = hand_r.head.copy()
        ik_hand_r.tail = hand_r.tail.copy()
        #k_hand_r.use_connect = True
        ik_hand_r.layers = self.IKLayers
        ik_hand_r.use_deform = True
        
        bpy.ops.object.mode_set(mode = 'POSE')
        
        pbone = pose_bones.get('ik_foot_root')
        c = pbone.constraints.new(type='COPY_TRANSFORMS')
        c.target = rig
        c.subtarget = 'root'
        
        pbone = pose_bones.get('ik_foot_l')
        c = pbone.constraints.new(type='COPY_TRANSFORMS')
        c.target = rig
        c.subtarget = foot_l_name
        
        pbone = pose_bones.get('ik_foot_r')
        c = pbone.constraints.new(type='COPY_TRANSFORMS')
        c.target = rig
        c.subtarget = foot_r_name
        
        pbone = pose_bones.get('ik_hand_gun')
        c = pbone.constraints.new(type='COPY_TRANSFORMS')
        c.target = rig
        c.subtarget = hand_r_name
        
        #pbone = pose_bones.get('ik_hand_gun')
        #c = pbone.constraints.new(type='STRETCH_TO')
        #c.target = rig
        #c.subtarget = 'hand_l_name'
                
        pbone = pose_bones.get('ik_hand_r')
        c = pbone.constraints.new(type='COPY_TRANSFORMS')
        c.target = rig
        c.subtarget = hand_r_name
        
        pbone = pose_bones.get('ik_hand_l')
        c = pbone.constraints.new(type='COPY_TRANSFORMS')
        c.target = rig
        c.subtarget = hand_l_name
        
        return {"FINISHED"}
    
    def sanity_checks(self):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        
        bpy.ops.object.mode_set(mode='POSE')
        
        pbones = metarig.pose.bones
        
        mode = self.rig_mode
        
        for name in self.BoneMap:
            if len(name) < 3:
                self.report({'ERROR'}, "Metarig bone names must be atleast 3 characters.")
                return False
            type = pbones[name].rigify_type
            if type == 'limbs.super_limb':
                suffix = name[-3:]
                if suffix.isnumeric():
                    self.report({'ERROR'}, "Metarig limb (arm, leg, paw etc) bone names can not end in a number and must be unique.")
                    return False
            
        return True
    
    def get_suffix(self, name):
        
        suffix = name[-2:]
        
        if suffix == '.l':
            return '.l'
        elif suffix == '.L':
            return '.L'
        elif suffix == '_l':
            return '_l'
        elif suffix == '_L':
            return '_L'
        elif suffix == '.r':
            return '.r'
        elif suffix == '.R':
            return '.R'
        elif suffix == '_r':
            return '_r'
        elif suffix == '_R':
            return '_R'
            
        return ""
    
    def stretch_off(self):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        rig = bpy.data.objects.get(self.rig_name)
        
        bpy.ops.object.mode_set(mode='POSE')
        
        pbones = metarig.pose.bones
        
        limbs = []
        for name in self.BoneMap:
            limb = pbones.get(name)
            if limb is not None and limb.rigify_type == 'limbs.super_limb':
                limbs.append(limb.name)
        
        pbones = rig.pose.bones
        
        for limb in limbs:
            suffix = self.get_suffix(limb)
            name = limb[:-2] + '_parent' + suffix
            parent = pbones.get(name)
            if parent is not None:
                parent["IK_Stretch"] = 0.0
            
        return
    
    @classmethod
    def poll(cls, context):
        return context.armature
    
    def execute(self, context):
        
        metarig = bpy.data.objects.get(self.metarig_name)
        rig = bpy.data.objects.get(self.rig_name)
        mode = self.rig_mode
                
        if metarig is None:
            self.report({'ERROR'}, "Metarig is not set in Uefy Script panel")
            return {'FINISHED'}
        if rig is None:
            self.report({'ERROR'}, "Rig is not set in Uefy Script panel")
            return {'FINISHED'}
        
        bpy.ops.uefy.scan(metarig_name=self.metarig_name)
        
        map = bpy.data.texts["uefy_bonemap.json"].as_string()
        self.BoneMap = json.loads(map)
        
        success = self.sanity_checks()
        if success == False:
            bpy.ops.object.mode_set(mode='OBJECT')
            return {'FINISHED'}
        
        for name in self.BoneMap:
            self.process_type(name)
        
        if mode == 0:
            self.do_add_ik()
        self.disable_deforms()
        self.rename_head()
        
        self.stretch_off()
        
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'
        
        if mode == 0:
            bpy.ops.uefy.weight_paint(target_name=self.rig_name)
        
        rig.name = 'Armature'
        
        bpy.ops.object.mode_set(mode='POSE')
        
        return {'FINISHED'}
    
class UEFY_OT_default_weight_paint(bpy.types.Operator):
    bl_idname = "uefy.weight_paint"
    bl_label = "Weight Paint"
    bl_description = "Enable default weight paint for skeleton"
    
    target_name : StringProperty()
    
    @classmethod
    def poll(cls, context):
        return context.armature
        
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        target = bpy.data.objects.get(self.target_name)
        
        ebones = target.data.edit_bones
        
        for bone in ebones:
            if bone.use_deform == True:
                vname = VertexGroupLookup.get(bone.name)
                if vname is not None:
                    check = ebones.get(vname)
                    if check is not None:
                        self.report({'WARNING'}, "Bone: " + vname + " already exists. Undo this step, rename the other bone to something else and try again.")
                    bone.name = vname
        
        # Patch for head bone
        for ob in target.children:
            if ob.type == 'MESH':
                for vg in ob.vertex_groups:
                    if vg.name == 'head_01':
                        vg.name = 'head'
        
        bpy.ops.object.mode_set(mode='POSE')
        
        return {'FINISHED'}
        
classes = ( UEFY_OT_build_skeleton, UEFY_OT_default_weight_paint)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    
def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
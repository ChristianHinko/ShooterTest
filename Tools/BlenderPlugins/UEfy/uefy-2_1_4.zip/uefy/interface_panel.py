"""
Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq
https://www.rakiz.com

Created by Rakiz Farooq

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

"""
Uefy 2 is an addon for Blender that provides tools to make Rigify rigs 
suitable for use in game engines.

This addon is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support 
this project and help ensure continued development.
"""
import bpy

from bpy.props import *

match_key_modes = [ 
                ('0', 'Whole Character', 'Key entire character for every frame'),
                ('1', 'Whole Character (Selected)', 'Key only selected bones for the character on each frame')
            ]

rig_modes = [ 
                ('0', 'Epic Skeleton', 'Default skeleton of UE4 mann.'),
                ('1', 'Free Form', 'Rigify Mode')
            ]

twist_modes = [
                ('2', 'Full', 'All twist bones added as specified by metarig config'),
                ('1', 'Default', 'Match default skeleton of UE4 mann.'),
                ('0', 'No Twist', 'No twist bones will be added to limbs')
                ]

limb_types = [
                ('0', 'Spine', 'Character Spine chain 6 bones'),
                ('1', 'Left Leg', 'Left Leg chain 4 bones'),
                ('2', 'Left Arm', 'Left Arm chain 4 bones (from shoulder to hand)'),
                ('3', 'L. Index', 'Left Index Finger 3 bones'),
                ('4', 'L. Middle', 'Left Middle Finger 3 bones'),
                ('5', 'L. Ring', 'Left Ring Finger 3 bones'),
                ('6', 'L. Pinky', 'Left Pinky Finger 3 bones'),
                ('7', 'L. Thumb', 'Left Thumb Finger 3 bones'),
                ('8', 'Right Leg', 'Right Leg chain 4 bones'),
                ('9', 'Right Arm', 'Right Arm chain 4 bones (from shoulder to hand)'),
                ('10', 'R. Index', 'Right Index Finger 3 bones'),
                ('11', 'R. Middle', 'Right Middle Finger 3 bones'),
                ('12', 'R. Ring', 'Right Ring Finger 3 bones'),
                ('13', 'R. Pinky', 'Right Pinky Finger 3 bones'),
                ('14', 'R. Thumb', 'Right Thumb Finger 3 bones')]

mirror_types = [
                ('0', 'Active Bone Only', 'Mirror only active bone'),
                ('1', 'All Bones (Left to Right)', 'Mirror all bone weights from Left to Right'),
                ('2', 'All Bones (Right to Left)', 'Mirror all bone weights from Right to Left')]
    
axis_types = [
                ('0', '+ x-axis', 'Align to positive X-Axis'),
                ('1', '- x-axis', 'Align to negative X-Axis'),
                ('2', '+ z-axis', 'Align to positive Z-Axis'),
                ('3', '- z-axis', 'Align to negative Z-Axis')]
    
def UEFY_CALL_get_character_templates(self, context):
    list = [('0', ' --- Select Mapping --- ', 'Select character template mapping')]
    
    for text in bpy.data.texts:
        prefix = text.name[:13]
        postfix = text.name[-5:]
        if prefix == 'uefy_mapping_' and postfix == '.json':
            list.append((text.name, text.name[13:-5], "Edit '" + text.name + "' to update this mapping"))
    
    return list
    
def UEFY_CALL_get_anim_templates(self, context):
    list = [('0', ' --- Select Mapping --- ', 'Select animation template mapping')]
    
    for text in bpy.data.texts:
        prefix = text.name[:10]
        postfix = text.name[-5:]
        if prefix == 'uefy_anim_' and postfix == '.json':
            list.append((text.name, text.name[10:-5], "Edit '" + text.name + "' to update this mapping"))
    
    return list
    
def UEFY_CALL_get_skin_templates(self, context):
    list = [('0', ' --- Select Skin --- ', 'Select skin template mapping')]
    
    for text in bpy.data.texts:
        prefix = text.name[:10]
        postfix = text.name[-5:]
        if prefix == 'uefy_skin_' and postfix == '.json':
            list.append((text.name, text.name[10:-5], "Edit '" + text.name + "' to update this mapping"))
    
    return list
    
def UEFY_CALL_get_vgs_templates(self, context):
    list = [('0', ' --- Select Vertex Groups --- ', 'Select vertex groups template mapping')]
    
    for text in bpy.data.texts:
        prefix = text.name[:9]
        postfix = text.name[-5:]
        if prefix == 'uefy_vgs_' and postfix == '.json':
            list.append((text.name, text.name[9:-5], "Edit '" + text.name + "' to update this mapping"))
    
    return list

class UEFY_armature_item(bpy.types.PropertyGroup):
    name : bpy.props.StringProperty(name="Armature")
    
    
class UEFY_scene_properties(bpy.types.PropertyGroup):
    bpy.types.Scene.uefy_character_name = StringProperty(name = "Character", default="Armature")
    bpy.types.Scene.uefy_uemann_name = StringProperty(name = "UE Mannequin", default="root")
    bpy.types.Scene.uefy_metarig_name = StringProperty(name = "Metarig", default="metarig")
    bpy.types.Scene.uefy_rig_name = StringProperty(name = "Rig", default="rig")
    
    bpy.types.Scene.uefy_anim_name = StringProperty(name = "Anim Source", default="root.001")
    
    
    bpy.types.Scene.uefy_rig_mode = EnumProperty(
        name = "Mode ",
        description = "Select the type of rig to process",
        items = rig_modes,
        default = '0'
    )
    
    bpy.types.Scene.uefy_match_key_mode = EnumProperty(
        name = "Mode ",
        description = "Select type for key insertion for each frame",
        items = match_key_modes,
        default = '0'
    )
    
    bpy.types.Scene.uefy_character_mappings = EnumProperty(
        name = "",
        description = "Character Mapping",
        items = UEFY_CALL_get_character_templates,
        default = None
    )
    
    bpy.types.Scene.uefy_anim_mappings = EnumProperty(
        name = "",
        description = "Animation Armature",
        items = UEFY_CALL_get_anim_templates,
        default = None
    )
    
    bpy.types.Scene.uefy_fix_metarig = BoolProperty(
        name = "Fix Metarig",
        description = "Remove metarig plam and neck bones",
        default = True
    )
    
    bpy.types.Scene.uefy_rig_to_armature = BoolProperty(
        name = "Rig to Armature",
        description = "Change rig name to armature",
        default = True
    )
    
    bpy.types.Scene.uefy_armature_to_rig = BoolProperty(
        name = "Armature to Rig",
        description = "Change armature name to rig",
        default = False
    )
    
    bpy.types.Scene.uefy_remove_face = BoolProperty(
        name = "Remove Face",
        description = "Remove metarig face bones",
        default = True
    )
    
    bpy.types.Scene.uefy_remove_extras_chest = BoolProperty(
        name = "Remove Extras: Chest",
        description = "Remove metarig breast bones",
        default = True
    )

    bpy.types.Scene.uefy_remove_extras_pelvis = BoolProperty(
        name = "Remove Extras: Pelvis",
        description = "Remove metarig pelvis bones",
        default = True
    )
    
    bpy.types.Scene.uefy_add_twist = BoolProperty(
        name = "Twist Compatibility",
        description = "Arrange twist bones like they are in the mannequin",
        default = True
    )
    
    bpy.types.Scene.uefy_fix_fingers = BoolProperty(
        name = "Fix Fingers",
        description = "Set fingers to Manual X-Axis instead of automatic",
        default = True
    )
    
    bpy.types.Scene.uefy_axis_type = EnumProperty(
        name = "Axis ",
        description = "Align axis to",
        items = axis_types,
        default = '0'
    )
    
    bpy.types.Scene.uefy_skin_mappings = EnumProperty(
        name = "",
        description = "Skin Mapping",
        items = UEFY_CALL_get_skin_templates,
        default = None
    )
    
    bpy.types.Scene.uefy_vgs_mappings = EnumProperty(
        name = "",
        description = "Vertex Group Mapping",
        items = UEFY_CALL_get_vgs_templates,
        default = None
    )
    
    bpy.types.Scene.uefy_limb_type = EnumProperty(
        name = "Chain ",
        description = "Rename bones in chain",
        items = limb_types,
        default = '0'
    )
    
    bpy.types.Scene.uefy_mirror_type = EnumProperty(
        name = "Mirror ",
        description = "Mirror bone weight paint in character",
        items = mirror_types,
        default = '0'
    )

    bpy.types.Scene.uefy_mirror_topology = BoolProperty(
        name = "Use Topology",
        description = "Mirror based on Topology for meshes when both sides have matching but unique topology",
        default = True
    )
    
    bpy.types.Scene.uefy_twist_mode = EnumProperty(
        name = "Twist",
        description = "Select type twists to add to the skeleton",
        items = twist_modes,
        default = '1'
    )
    
    bpy.types.Scene.uefy_extract_all_meshes = BoolProperty(
        name = "Extract All",
        description = "Extract all meshes attached to the parent armature",
        default = True
    )
    
    bpy.types.Scene.uefy_move_thigh_twist = BoolProperty(
        name = "Move Thigh Twist",
        description = "Move the thigh twist to Original UE4 Mannequin location. Uncheck this if you have more than default number of twist bones.",
        default = True
    )
    
    bpy.types.Scene.uefy_start_frame = IntProperty(
        name = "Start Frame",
        description = "Start Frame for multi frame animation pose matching",
        default = 1
    )
    
    bpy.types.Scene.uefy_end_frame = IntProperty(
        name = "End Frame",
        description = "End Frame for multi frame animation pose matching",
        default = 1
    )
    
class UEFY_OT_refresh_armature_list(bpy.types.Operator):
    bl_idname = "uefy.refresh_armature_list"
    bl_label = "Refresh List"
    bl_description = "Refresh available Armatures (needed if some armature objects were renamed)"
    
    def execute(self, context):
        
        scene = context.scene
        scene.uefy_character_objects.clear()
        
        for ob in scene.objects:
            if ob.type == 'ARMATURE':
                scene.uefy_character_objects.add().name = ob.name
        
        return {"FINISHED"}

class UEFY_PT_view_panel(bpy.types.Panel):
    bl_idname = "UEFY_PT_view_panel"
    bl_label = "Uefy Script Panel"
    #bl_category = "Tab name"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"
    
    def draw(self, context):
        
        layout = self.layout
        
        scene = context.scene
        
        row = layout.row()
        row.label(text="Properties: ")
        
        row = layout.row()
        box = row.box()
        
        row = box.row()
        row.prop_search(scene, "uefy_character_name", scene, "uefy_character_objects")
        row = box.row()
        row.prop_search(scene, "uefy_uemann_name", scene, "uefy_character_objects")
        row = box.row()
        row.prop_search(scene, "uefy_metarig_name", scene, "uefy_character_objects")
        row = box.row()
        row.prop_search(scene, "uefy_rig_name", scene, "uefy_character_objects")
        row = box.row()
        row.alignment = 'RIGHT'
        row.operator("uefy.refresh_armature_list")
        
        row = layout.row()
        row.label(text="Mannequin Setup: ")
        
        row = layout.row()
        props = row.operator("uefy.fix_mannequin", text = "Fix Mannequin")
        props.uemann_name = scene.uefy_uemann_name
        
        row = layout.row()
        row.label(text="Character Operators: ")
        
        row = layout.row()
        box = row.box()
        row = box.row()
        col = row.column()
        col.prop(scene, "uefy_character_mappings")
        col = row.column()
        col.alignment = 'RIGHT'
        props = col.operator("uefy.load_mapping", text = "", icon = "FILE_REFRESH")
        row = box.row()
        col = row.column()
        props = col.operator("uefy.scan_character", text = "Scan")
        props.character_name = scene.uefy_character_name
        col = row.column()
        props = col.operator("uefy.rename_bones", text = "Apply")
        props.character_mapping = scene.uefy_character_mappings
        props.target_name = scene.uefy_character_name
        
        row = layout.row()
        props = row.operator("uefy.auto_roll_bones", text = "Magic Rolls")
        props.target_name = scene.uefy_character_name

        row = layout.row()
        props = row.operator("uefy.pose_character", text = "Pose Character")
        props.uemann_name = scene.uefy_uemann_name
        props.character_name = scene.uefy_character_name
        
        row = layout.row()
        row.label(text="Metarig Operators: ")

        row = layout.row()
        box = row.box()

        row = box.row()
        col = row.column()
        props = col.operator("uefy.fix_metarig", text = "Fix Metarig")
        props.target_name = scene.uefy_metarig_name
        props.fix_metarig = scene.uefy_fix_metarig
        props.remove_face = scene.uefy_remove_face
        props.remove_extras_chest = scene.uefy_remove_extras_chest
        props.remove_extras_pelvis = scene.uefy_remove_extras_pelvis
        props.add_twist = scene.uefy_add_twist
        props.fix_fingers = scene.uefy_fix_fingers
        props.rig_mode = scene.uefy_rig_mode
        
        col = row.column()
        col.alignment = 'RIGHT'
        col.enabled = False
        col.prop(scene, 'uefy_fix_metarig')
        row = box.row()
        row.prop(scene, 'uefy_remove_face')
        row = box.row()
        row.prop(scene, 'uefy_remove_extras_chest')
        row = box.row()
        row.prop(scene, 'uefy_remove_extras_pelvis')
        row = box.row()
        row.prop(scene, 'uefy_add_twist')
        row = box.row()
        row.prop(scene, 'uefy_fix_fingers')
        
        row = layout.row()
        props = row.operator("uefy.pose_metarig", text = "Pose Metarig")
        props.metarig_name = scene.uefy_metarig_name
        props.character_name = scene.uefy_character_name
        
        #row = layout.row()
        #row.label(text="Preprocess Operators: ")
        #
        #row = layout.row()
        #box = row.box()
        #row = box.row()
        #col = row.column()
        #props = col.operator("uefy.scan", text = "Preprocess")
        #props.metarig_name = scene.uefy_metarig_name
        #col = row.column()
        #props = col.operator("uefy.verify_map", text = "Verify")
        #props.metarig_name = scene.uefy_metarig_name
        #row = box.row()
        #props = row.operator("uefy.auto_fix_map", text = "Auto Fix")
        #props.metarig_name = scene.uefy_metarig_name
        
        row = layout.row()
        row.label(text="Generated Rig Operators: ")
        
        row = layout.row()
        box = row.box()
        row = box.row()
        row.prop(scene, 'uefy_rig_mode')
        if scene.uefy_rig_mode == "0":
            row = box.row()
            row.prop(scene, 'uefy_twist_mode')
        row = box.row()
        props = row.operator("uefy.build_skeleton", text = "Build Skeleton")
        props.metarig_name = scene.uefy_metarig_name
        props.rig_name = scene.uefy_rig_name
        props.rig_mode = int(scene.uefy_rig_mode)
        props.twist_mode = int(scene.uefy_twist_mode)
        
        #row = layout.row()
        #row.label(text="Weight Paint Operators: ")
        
        #row = layout.row()
        #props = row.operator("uefy.weight_paint", text = "Default Weight Paint")
        #props.target_name = scene.uefy_rig_name
        
        #row = layout.row()
        #props = row.operator("uefy.test", text = "Test Button")
        
        
class UEFY_PT_extra_panel(bpy.types.Panel):
    bl_idname = "UEFY_PT_extra_panel"
    bl_label = "Uefy Extra Tools"
    bl_category = "Uefy Extra Tools"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"
    
    def draw(self, context):
        layout = self.layout
        
        scene = context.scene
        
        row = layout.row()
        row.label(text="Armature Name Tool: ")
        
        row = layout.row()
        box = row.box()
        row = box.row()
        col = row.column()
        props = col.operator("uefy.rig_name", text = "To Armature")
        props.export = True
        col = row.column()
        props = col.operator("uefy.rig_name", text = "To Rig")
        props.export = False
        
        row = layout.row()
        row.label(text="Mesh Extract Tool:")
        row = layout.row()
        box = row.box()
        row = box.row()
        props = row.operator("uefy.extract_mesh", text = "Extract Mesh")
        props.all_meshes = scene.uefy_extract_all_meshes
        row = box.row()
        row.prop(scene, "uefy_extract_all_meshes")
        
        row = layout.row()
        row.label(text="Pose Update Tool:")
        row = layout.row()
        props = row.operator("uefy.force_rest_pose", text = "Update 'Rest Pose'")
        
        row = layout.row()
        row.label(text="Skinning Rename Tool: ")
        
        row = layout.row()
        box = row.box()
        row = box.row()
        col = row.column()
        col.prop(scene, "uefy_skin_mappings")
        col = row.column()
        col.alignment = 'RIGHT'
        col.operator("uefy.load_skins", text="", icon="FILE_REFRESH")
        row = box.row()
        col = row.column()
        col.operator("uefy.skin_scan_armature", text = "Scan Armature")
        col = row.column()
        props = col.operator("uefy.skin_apply", text = "Apply Armature")
        props.skin_mapping = scene.uefy_skin_mappings
        
        row = layout.row()
        box = row.box()
        row = box.row()
        col = row.column()
        col.prop(scene, "uefy_vgs_mappings")
        col = row.column()
        col.alignment = 'RIGHT'
        col.operator("uefy.load_vgs", text="", icon="FILE_REFRESH")
        row = box.row()
        col = row.column()
        col.operator("uefy.skin_scan_vgs", text = "Scan VGs")
        col = row.column()
        props = col.operator("uefy.vgs_apply", text = "Apply VGs")
        props.vgs_mapping = scene.uefy_vgs_mappings
        
        row = layout.row()
        row.label(text="Bone Rename Tool:")
        row = layout.row()
        box = row.box()
        row = box.row()
        row.prop(scene, 'uefy_limb_type')
        row = box.row()
        props = row.operator("uefy.bone_rename")
        props.limb_type = int(scene.uefy_limb_type)
        
        row = layout.row()
        row.label(text="Bone Roll Tool:")
        row = layout.row()
        box = row.box()
        row = box.row()
        row.prop(scene, 'uefy_axis_type') 
        row = box.row()
        props = row.operator("uefy.roll_bone")
        props.axis_type = int(scene.uefy_axis_type)
        row = box.row()
        props = row.operator("uefy.swap_y_axis")
        props.axis_type = int(scene.uefy_axis_type)
        
        #row = layout.row()
        #row.label(text="Bone Mirror Weight Tool")
        #row = layout.row()
        #box = row.box()
        #row = box.row()
        #row.prop(scene, 'uefy_mirror_type')
        #row = box.row()
        #row.prop(scene, 'uefy_mirror_topology')
        #row = box.row()
        #props = row.operator("uefy.mirror_weights")
        #props.mirror_type = int(scene.uefy_mirror_type)
        #props.use_topology = scene.uefy_mirror_topology
        
        row = layout.row()
        row.label(text="Export Panel: ")
        
        row = layout.row()
        box = row.box()
        row = box.row()
        row.label(text="Caution: Incompatible for Rigify!", icon='ERROR')
        row = box.row()
        props = row.operator("uefy.ue_export_align")
        props.move_thigh_twist = scene.uefy_move_thigh_twist
        row = box.row()
        row.prop(scene, 'uefy_move_thigh_twist')
        
class UEFY_PT_anim_panel(bpy.types.Panel):
    bl_idname = "UEFY_PT_anim_panel"
    bl_label = "Uefy Animation Tools"
    bl_category = "Uefy Anim Tools"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"
    
    def draw(self, context):
        layout = self.layout
        
        scene = context.scene
        
        row = layout.row()
        box = row.box()
        row = box.row()
        row.prop_search(scene, "uefy_anim_name", scene, "uefy_character_objects")
        row = box.row()
        row.alignment = 'RIGHT'
        row.operator("uefy.refresh_armature_list")
        
        row = layout.row()
        row.label(text="Animation Pose Matching: ")
        row = layout.row()
        box = row.box()
        row = box.row()
        col = row.column()
        col.prop(scene, "uefy_anim_mappings")
        col = row.column()
        col.alignment = 'RIGHT'
        props = col.operator("uefy.load_anim_mapping", text = "", icon = "FILE_REFRESH")
        row = box.row()
        col = row.column()
        props = col.operator("uefy.scan_anim", text = "Scan Anim")
        props.source_name = scene.uefy_anim_name
        col = row.column()
        props = col.operator("uefy.match_pose", text = "Match Pose")
        props.source_name = scene.uefy_anim_name
        props.target_name = scene.uefy_rig_name
        props.anim_mapping = scene.uefy_anim_mappings
        
        row = layout.row()
        row.label(text="Multi Frame Match Tool:")
        row = layout.row()
        box = row.box()
        row = box.row()
        row.prop(scene, "uefy_start_frame")
        row = box.row()
        row.prop(scene, "uefy_end_frame")
        row = box.row()
        row.prop(scene, 'uefy_match_key_mode')
        row = box.row()
        props = row.operator("uefy.match_multi_frame", text="Multi Frame")
        props.source_name = scene.uefy_anim_name
        props.target_name = scene.uefy_rig_name
        props.anim_mapping = scene.uefy_anim_mappings
        props.start_frame = scene.uefy_start_frame
        props.end_frame = scene.uefy_end_frame
        props.key_mode = scene.uefy_match_key_mode
        
    
    
class UEFY_MT_uefy_menu(bpy.types.Menu):
    bl_label = "Uefy Script"
    bl_idname = "UEFY_MT_uefy_menu"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Uefy Metarigs")
        
        layout.menu("UEFY_MT_uefy_skeleton_menu")
        
        props = layout.operator("uefy.add_menu_mann_metarig", text="Mannequin Metarig", icon='OUTLINER_OB_ARMATURE')
        props.ob_name = 'metarig'
        
        return
    
    
class UEFY_MT_uefy_skeleton_menu(bpy.types.Menu):
    bl_label = "Reference Skeleton"
    bl_idname = "UEFY_MT_uefy_skeleton_menu"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Reference Skeletons")
        
        props = layout.operator("uefy.add_menu_mann_proxy", text="Mannequin Skeleton Proxy (A-Pose)")
        props.ob_name = 'mannequin'
        
        props = layout.operator("uefy.add_menu_basic_posing", text="Basic Posing Skeleton")
        props.ob_name = 'character'
        
        return
    
def uefy_menu(self, context):
    self.layout.menu(UEFY_MT_uefy_menu.bl_idname, icon='OUTLINER_OB_ARMATURE')
    
    
classes = ( UEFY_armature_item, UEFY_scene_properties,
            UEFY_OT_refresh_armature_list,
            UEFY_PT_view_panel,
            UEFY_PT_extra_panel,
            UEFY_PT_anim_panel,
            UEFY_MT_uefy_menu, UEFY_MT_uefy_skeleton_menu)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    
    bpy.types.VIEW3D_MT_armature_add.append(uefy_menu)
    
    bpy.types.Scene.uefy_character_objects = CollectionProperty(type=UEFY_armature_item)

    
def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    
    bpy.types.VIEW3D_MT_armature_add.remove(uefy_menu)
    
    del bpy.types.Scene.uefy_character_objects
    del bpy.types.Scene.uefy_character_mappings
    del bpy.types.Scene.uefy_anim_mappings
    del bpy.types.Scene.uefy_skin_mappings
    del bpy.types.Scene.uefy_vgs_mappings
    del bpy.types.Scene.uefy_rig_mode
    del bpy.types.Scene.uefy_match_key_mode
    del bpy.types.Scene.uefy_character_name
    del bpy.types.Scene.uefy_uemann_name
    del bpy.types.Scene.uefy_metarig_name
    del bpy.types.Scene.uefy_rig_name
    del bpy.types.Scene.uefy_anim_name
    del bpy.types.Scene.uefy_fix_metarig
    del bpy.types.Scene.uefy_remove_face
    del bpy.types.Scene.uefy_remove_extras_chest
    del bpy.types.Scene.uefy_remove_extras_pelvis
    del bpy.types.Scene.uefy_add_twist
    del bpy.types.Scene.uefy_fix_fingers
    del bpy.types.Scene.uefy_limb_type
    del bpy.types.Scene.uefy_mirror_type
    del bpy.types.Scene.uefy_mirror_topology
    del bpy.types.Scene.uefy_twist_mode
    del bpy.types.Scene.uefy_rig_to_armature
    del bpy.types.Scene.uefy_armature_to_rig
    del bpy.types.Scene.uefy_extract_all_meshes
    del bpy.types.Scene.uefy_move_thigh_twist
    del bpy.types.Scene.uefy_start_frame
    del bpy.types.Scene.uefy_end_frame

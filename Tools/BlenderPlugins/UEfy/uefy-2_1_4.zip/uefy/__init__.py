"""
Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq
https://www.rakiz.com

Created by Rakiz Farooq

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

"""
Uefy 2 is an addon for Blender that provides tools to make Rigify rigs 
suitable for use in game engines.

This addon is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support 
this project and help ensure continued development.
"""

bl_info = {
    "name" : "Uefy Script",
    "author" : "Rakiz Farooq",
    "description" : "Make Rigify rigs compatible for game engines.",
    "version" : (2, 1, 4),
    "blender" : (2, 83, 0),
    "location" : "View3D",
    "category" : "Rigging"
}

import bpy
from bpy.props import *

from . import (interface_panel, debug_tool, scan, pose, build, extra, match)
from .rigs import (rig_mann_metarig, rig_basic_posing, rig_mann_proxy)

classes = ()

#register, unregister = bpy.utils.register_classes_factory(classes)

def register():
    from bpy.utils import register_class
    
    interface_panel.register()
    debug_tool.register()
    scan.register()
    pose.register()
    build.register()
    extra.register()
    match.register()
    rig_mann_metarig.register()
    rig_basic_posing.register()
    rig_mann_proxy.register()
    
    for cls in classes:
        register_class(cls)

def unregister():
    from bpy.utils import unregister_class
    
    rig_mann_proxy.unregister()
    rig_basic_posing.unregister()
    rig_mann_metarig.unregister()
    match.unregister()
    extra.unregister()
    build.unregister()
    pose.unregister()
    scan.unregister()
    debug_tool.unregister()
    interface_panel.unregister()
    
    for cls in reversed(classes):
        unregister_class(cls)



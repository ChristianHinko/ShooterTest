"""
Uefy v2.1.4 (Pro Edition)

Copyright (c) 2020 Rakiz Farooq
https://www.rakiz.com

Created by Rakiz Farooq

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

"""
Uefy 2 is an addon for Blender that provides tools to make Rigify rigs 
suitable for use in game engines.

This addon is available for sale at https://www.rakiz.com/uefy

This project relies on sales for funding. Please purchase your copy to support 
this project and help ensure continued development.
"""
import bpy
import json

from bpy.props import StringProperty

class UEFY_OT_test(bpy.types.Operator):
    bl_idname = "uefy.test"
    bl_label = "Test Button"
    bl_description = "Test Button"
    
    
    def execute(self, context):
        
        print("Test Button")
        
        return {'FINISHED'}
        
classes = (UEFY_OT_test,)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    
def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)